#!/usr/bin/env bash
# One-command cloud setup for aptmon (run from this folder on your Mac):
#     bash setup_github.sh
# Creates a GitHub repo, uploads the code, sets up hosting for the iPhone app, stores your alert
# channel as a secret, and runs the first price check. Safe to re-run.
set -euo pipefail

REPO_NAME="${REPO_NAME:-aptmon}"
NTFY_TOPIC="${NTFY_TOPIC:-aptmon-S3PWILa96x3F}"     # your private alert channel (pre-generated, hard to guess)

say() { printf "\n\033[1m▸ %s\033[0m\n" "$*"; }

# 1. GitHub CLI
if ! command -v gh >/dev/null; then
  if command -v brew >/dev/null; then say "Installing GitHub CLI (brew install gh)"; brew install gh
  else echo "Install the GitHub CLI first: https://cli.github.com  (or install Homebrew: https://brew.sh)"; exit 1; fi
fi
if ! gh auth status >/dev/null 2>&1; then
  say "Sign in to GitHub (a browser window will open)"
  gh auth login --hostname github.com --git-protocol https --web --scopes "repo,workflow"
fi
OWNER="$(gh api user --jq .login)"
say "GitHub account: $OWNER"

# 2. Repo + code
if [ ! -d .git ]; then git init -q; fi
git checkout -q -B main
git add -A
git -c user.name="$OWNER" -c user.email="$OWNER@users.noreply.github.com" commit -qm "aptmon" || true
if gh repo view "$OWNER/$REPO_NAME" >/dev/null 2>&1; then
  say "Repo $OWNER/$REPO_NAME exists - pushing"
  git remote get-url origin >/dev/null 2>&1 || git remote add origin "https://github.com/$OWNER/$REPO_NAME.git"
  git push -u origin main
else
  say "Creating github.com/$OWNER/$REPO_NAME (public - required for free GitHub Pages)"
  gh repo create "$OWNER/$REPO_NAME" --public --source=. --remote=origin --push      --description "Daily 2BR rent monitor - Wolf Point East, Foundry, Lincoln Common, The Row"
fi

# 3. Settings: Actions may write (commit price history), Pages served from Actions
say "Configuring Actions permissions and GitHub Pages"
gh api -X PUT "repos/$OWNER/$REPO_NAME/actions/permissions/workflow"    -f default_workflow_permissions=write -F can_approve_pull_request_reviews=false >/dev/null
gh api -X POST "repos/$OWNER/$REPO_NAME/pages" -f build_type=workflow >/dev/null 2>&1   || gh api -X PUT "repos/$OWNER/$REPO_NAME/pages" -f build_type=workflow >/dev/null

# 4. Alert channel secret
say "Saving alert channel as secret NTFY_TOPIC"
gh secret set NTFY_TOPIC --repo "$OWNER/$REPO_NAME" --body "$NTFY_TOPIC"

# 5. First run
say "Starting the first price check (takes ~3-5 min)"
for i in 1 2 3 4 5 6; do            # a brand-new repo takes a few seconds to register its workflow
  gh workflow run monitor.yml --repo "$OWNER/$REPO_NAME" --ref main 2>/dev/null && break
  [ "$i" = 6 ] && { echo "Couldn't start the workflow - start it from the repo's Actions tab."; exit 1; }
  sleep 10
done
sleep 8
RUN_ID="$(gh run list --repo "$OWNER/$REPO_NAME" --workflow monitor.yml --limit 1 --json databaseId --jq '.[0].databaseId')"
gh run watch "$RUN_ID" --repo "$OWNER/$REPO_NAME" --exit-status || echo "(the run reported a problem - details: gh run view $RUN_ID --log-failed)"

URL="https://$OWNER.github.io/$REPO_NAME/"
cat <<DONE

✅ Done. Two things on your iPhone:

  1) Alerts:    install "ntfy" from the App Store, tap +, subscribe to:   $NTFY_TOPIC
                (or open https://ntfy.sh/$NTFY_TOPIC on the phone and tap "Subscribe")
  2) Dashboard: open  $URL  in Safari → Share → Add to Home Screen

Runs every day at 7:00 AM Central. Manual check anytime: GitHub app → $REPO_NAME → Actions → Run workflow.
DONE
