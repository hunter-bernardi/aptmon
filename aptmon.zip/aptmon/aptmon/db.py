"""SQLite storage: one row per unit, one price observation per unit per scrape run."""
from __future__ import annotations

import json
import os
import sqlite3
from contextlib import contextmanager

SCHEMA = """
CREATE TABLE IF NOT EXISTS runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    started TEXT NOT NULL, finished TEXT, summary TEXT
);
CREATE TABLE IF NOT EXISTS scrape_status (
    run_id INTEGER, building TEXT, ok INTEGER, n_units INTEGER, n_seen INTEGER,
    scraper TEXT, error TEXT, ts TEXT,
    PRIMARY KEY (run_id, building)
);
CREATE TABLE IF NOT EXISTS units (
    key TEXT PRIMARY KEY, building TEXT, unit TEXT, beds REAL, baths REAL, sqft INTEGER,
    plan TEXT, url TEXT, available TEXT, first_seen TEXT, last_seen TEXT,
    status TEXT DEFAULT 'active', off_market_at TEXT, extra TEXT
);
CREATE TABLE IF NOT EXISTS prices (
    id INTEGER PRIMARY KEY AUTOINCREMENT, key TEXT, ts TEXT, price INTEGER, run_id INTEGER
);
CREATE INDEX IF NOT EXISTS ix_prices_key_ts ON prices(key, ts);
CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, key TEXT, building TEXT, unit TEXT,
    kind TEXT, old_price INTEGER, new_price INTEGER, message TEXT, notified INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS ix_events_ts ON events(ts);
CREATE TABLE IF NOT EXISTS concessions (
    building TEXT, norm TEXT, text TEXT, first_seen TEXT, last_seen TEXT, active INTEGER DEFAULT 1,
    PRIMARY KEY (building, norm)
);
"""


class DB:
    def __init__(self, path: str):
        self.path = path
        self.conn = sqlite3.connect(path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        # WAL locally (dashboard reads while a scrape writes); single-file DELETE mode in CI so the
        # committed .db is always complete.
        self.conn.execute("PRAGMA journal_mode=" + ("DELETE" if os.environ.get("CI") else "WAL"))
        self.conn.executescript(SCHEMA)

    @contextmanager
    def tx(self):
        try:
            yield self.conn
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise

    def q(self, sql, *args):
        return [dict(r) for r in self.conn.execute(sql, args).fetchall()]

    def one(self, sql, *args):
        r = self.conn.execute(sql, args).fetchone()
        return dict(r) if r else None

    # ---- runs ----
    def start_run(self, ts) -> int:
        with self.tx() as c:
            return c.execute("INSERT INTO runs(started) VALUES (?)", (ts,)).lastrowid

    def finish_run(self, run_id, ts, summary: dict):
        with self.tx() as c:
            c.execute("UPDATE runs SET finished=?, summary=? WHERE id=?", (ts, json.dumps(summary), run_id))

    def record_status(self, run_id, building, ok, n_units, n_seen, scraper, error, ts):
        with self.tx() as c:
            c.execute("INSERT OR REPLACE INTO scrape_status VALUES (?,?,?,?,?,?,?,?)",
                      (run_id, building, int(ok), n_units, n_seen, scraper, error, ts))

    def last_status(self, building):
        return self.one("SELECT * FROM scrape_status WHERE building=? ORDER BY run_id DESC LIMIT 1", building)

    # ---- units / prices ----
    def get_unit(self, key):
        return self.one("SELECT * FROM units WHERE key=?", key)

    def last_price(self, key):
        r = self.one("SELECT price FROM prices WHERE key=? ORDER BY ts DESC, id DESC LIMIT 1", key)
        return r["price"] if r else None

    def active_keys(self, building) -> set[str]:
        return {r["key"] for r in self.q("SELECT key FROM units WHERE building=? AND status='active'", building)}

    def listing_map(self, building) -> dict:
        """Related listing-id -> {unit, sqft}, so detail pages are fetched once per listing."""
        out = {}
        for r in self.q("SELECT unit, sqft, extra FROM units WHERE building=?", building):
            ex = json.loads(r["extra"] or "{}")
            if ex.get("listing_id") and not r["unit"].startswith("L"):
                out[ex["listing_id"]] = {"unit": r["unit"], "sqft": r["sqft"]}
        return out

    def rename_key(self, old, new, new_unit):
        with self.tx() as c:
            if c.execute("SELECT 1 FROM units WHERE key=?", (new,)).fetchone():
                c.execute("UPDATE prices SET key=? WHERE key=?", (new, old))
                c.execute("DELETE FROM units WHERE key=?", (old,))
            else:
                c.execute("UPDATE units SET key=?, unit=? WHERE key=?", (new, new_unit, old))
                c.execute("UPDATE prices SET key=? WHERE key=?", (new, old))
            c.execute("UPDATE events SET key=?, unit=? WHERE key=?", (new, new_unit, old))

    def upsert_unit(self, u, ts):
        extra = json.dumps(u.extra or {})
        with self.tx() as c:
            c.execute("""
                INSERT INTO units(key, building, unit, beds, baths, sqft, plan, url, available,
                                  first_seen, last_seen, status, off_market_at, extra)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,'active',NULL,?)
                ON CONFLICT(key) DO UPDATE SET
                    beds=COALESCE(excluded.beds, beds), baths=COALESCE(excluded.baths, baths),
                    sqft=COALESCE(excluded.sqft, sqft), plan=COALESCE(excluded.plan, plan),
                    url=COALESCE(excluded.url, url), available=excluded.available,
                    last_seen=excluded.last_seen, status='active', off_market_at=NULL, extra=excluded.extra
            """, (u.key(), u.building, u.unit, u.beds, u.baths, u.sqft, u.plan, u.url, u.available,
                  ts, ts, extra))

    def add_price(self, key, ts, price, run_id):
        with self.tx() as c:
            c.execute("INSERT INTO prices(key, ts, price, run_id) VALUES (?,?,?,?)", (key, ts, price, run_id))

    def mark_off_market(self, key, ts):
        with self.tx() as c:
            c.execute("UPDATE units SET status='off_market', off_market_at=? WHERE key=?", (ts, key))

    # ---- concessions ----
    def sync_concessions(self, building, offers: dict[str, str], ts) -> list[tuple[str, str]]:
        """offers = {normalized: display text} seen this run. Returns [("concession"|"concession_end", text)]."""
        from datetime import datetime, timedelta
        # a special must be missing for a full day before it counts as ended (rotating banners flap)
        cutoff = (datetime.fromisoformat(ts.replace("Z", "")) - timedelta(days=1)).isoformat() + "Z"
        changes = []
        with self.tx() as c:
            prev = {r[0]: (r[1], r[2], r[3]) for r in c.execute(
                "SELECT norm, text, active, last_seen FROM concessions WHERE building=?", (building,))}
            for norm, text in offers.items():
                if norm not in prev or not prev[norm][1]:
                    changes.append(("concession", text))
                c.execute("""INSERT INTO concessions(building, norm, text, first_seen, last_seen, active)
                             VALUES (?,?,?,?,?,1)
                             ON CONFLICT(building, norm) DO UPDATE SET text=excluded.text,
                                 last_seen=excluded.last_seen, active=1""", (building, norm, text, ts, ts))
            for norm, (text, active, last_seen) in prev.items():
                if active and norm not in offers and (last_seen or "") < cutoff:
                    changes.append(("concession_end", text))
                    c.execute("UPDATE concessions SET active=0 WHERE building=? AND norm=?", (building, norm))
        return changes

    def active_concessions(self) -> list[dict]:
        return self.q("SELECT building, text, first_seen, last_seen FROM concessions WHERE active=1 "
                      "ORDER BY building, first_seen")

    # ---- events ----
    def add_event(self, ts, key, building, unit, kind, old, new, message) -> int:
        with self.tx() as c:
            return c.execute(
                "INSERT INTO events(ts, key, building, unit, kind, old_price, new_price, message) VALUES (?,?,?,?,?,?,?,?)",
                (ts, key, building, unit, kind, old, new, message)).lastrowid

    def mark_notified(self, ids):
        with self.tx() as c:
            c.executemany("UPDATE events SET notified=1 WHERE id=?", [(i,) for i in ids])
