"""HTTP + headless-browser fetching.

Two paths:
  * `get_html()`  - plain requests with browser headers; falls back to the browser on 403/empty.
  * `render()`    - Playwright page load that ALSO captures every JSON response the page makes.
                    Most leasing widgets (SightMap, RealPage, Related's search) hydrate from JSON,
                    so sniffing the network is far more stable than CSS selectors.
"""
from __future__ import annotations

import json
import logging
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

import requests

log = logging.getLogger("aptmon.fetch")

UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36")
HEADERS = {
    "User-Agent": UA,
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
}


@dataclass
class Rendered:
    url: str
    html: str
    json_payloads: list = field(default_factory=list)   # list[(url, parsed_json)]


class Fetcher:
    def __init__(self, cfg: dict, debug: bool = False):
        self.cfg = cfg
        self.timeout = cfg.get("request_timeout", 30)
        self.debug = debug
        self.debug_dir = Path(cfg["debug_dir"])
        self.session = requests.Session()
        self.session.headers.update(HEADERS)
        self._pw = None
        self._browser = None

    # ---------- plain HTTP ----------
    def get_html(self, url: str, allow_browser_fallback: bool = True) -> str:
        try:
            r = self.session.get(url, timeout=self.timeout)
            if r.status_code == 200 and len(r.text) > 2000:
                self.dump(url, r.text)
                return r.text
            log.info("GET %s -> %s (%d bytes); trying browser", url, r.status_code, len(r.text))
        except requests.RequestException as e:
            log.info("GET %s failed (%s); trying browser", url, e)
        if not allow_browser_fallback:
            return ""
        return self.render(url).html

    # ---------- headless browser ----------
    def _ensure_browser(self):
        if self._browser:
            return
        from playwright.sync_api import sync_playwright
        self._pw = sync_playwright().start()
        self._browser = self._pw.chromium.launch(headless=self.cfg.get("headless", True))

    def _new_context(self):
        """A context that looks a bit less like an automated one: a real locale/timezone (plenty of
        WAFs and anti-bot checks flag the Playwright default UTC/no-locale context on its own), and
        an override for navigator.webdriver, the single most common cheap tell that a page is being
        driven by an automation tool rather than a person's own Chrome."""
        ctx = self._browser.new_context(
            user_agent=UA, viewport={"width": 1440, "height": 1000},
            locale="en-US", timezone_id=self.cfg.get("timezone", "America/Chicago"))
        ctx.add_init_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
        return ctx

    def render(self, url: str, wait_ms: int = 4000,
               interact: Optional[Callable] = None,
               json_filter: Optional[Callable[[str], bool]] = None) -> Rendered:
        """Load `url` in Chromium, run optional `interact(page)`, return HTML + captured JSON.
        A goto() that times out or errors gets one retry after a short pause before giving up - a
        soft/rate-limit-style block or a one-off slow load can clear in a few seconds, and the
        bounded extra cost (one more `timeout` seconds, worst case) is cheap against the 30-minute
        job budget. A hard, persistent IP-level block won't be fixed by this - the retry's failure
        (or the debug screenshot from dump_failure(), captured on every attempt) is what tells you
        which kind you're looking at, not a guess."""
        self._ensure_browser()
        for attempt in (1, 2):
            ctx = self._new_context()
            page = ctx.new_page()
            payloads: list = []

            def on_response(resp):
                try:
                    ct = resp.headers.get("content-type", "")
                    if "json" not in ct:
                        return
                    if json_filter and not json_filter(resp.url):
                        return
                    payloads.append((resp.url, resp.json()))
                except Exception:
                    pass

            page.on("response", on_response)
            try:
                page.goto(url, wait_until="domcontentloaded", timeout=self.timeout * 2000)
            except Exception as e:
                self.dump_failure(url, page, e)
                ctx.close()
                if attempt == 1:
                    log.info("goto %s failed, retrying once in 15s: %s", url, e)
                    time.sleep(15)
                    continue
                raise
            try:
                try:
                    page.wait_for_load_state("networkidle", timeout=20000)
                except Exception:
                    pass
                page.wait_for_timeout(wait_ms)
                if interact:
                    interact(page)
                    try:
                        page.wait_for_load_state("networkidle", timeout=15000)
                    except Exception:
                        pass
                html = page.content()
            finally:
                ctx.close()
            self.dump(url, html, payloads)
            return Rendered(url=url, html=html, json_payloads=payloads)

    def close(self):
        try:
            if self._browser:
                self._browser.close()
            if self._pw:
                self._pw.stop()
        except Exception:
            pass
        self._browser = self._pw = None

    # ---------- debugging ----------
    def dump(self, url: str, html: str, payloads: list | None = None):
        if not self.debug:
            return
        self.debug_dir.mkdir(parents=True, exist_ok=True)
        stem = re.sub(r"[^a-zA-Z0-9]+", "_", url)[:120] + "_" + time.strftime("%H%M%S")
        (self.debug_dir / f"{stem}.html").write_text(html or "")
        if payloads:
            (self.debug_dir / f"{stem}.json").write_text(
                json.dumps([{"url": u, "data": d} for u, d in payloads], indent=1, default=str)[:20_000_000])

    def dump_failure(self, url: str, page, exc: Exception):
        """A goto() that times out or errors leaves no HTML to inspect - grab a screenshot and
        whatever partial page loaded anyway, so the debug artifact shows a CAPTCHA/"Attention
        Required" wall (bot-blocked) vs. a blank/broken page (something else), instead of just
        repeating the same bare timeout message every run."""
        if not self.debug:
            return
        try:
            self.debug_dir.mkdir(parents=True, exist_ok=True)
            stem = re.sub(r"[^a-zA-Z0-9]+", "_", url)[:120] + f"_{time.strftime('%H%M%S')}_FAILED"
            (self.debug_dir / f"{stem}.txt").write_text(f"{type(exc).__name__}: {exc}")
            try:
                page.screenshot(path=str(self.debug_dir / f"{stem}.png"), timeout=5000)
            except Exception as e2:
                log.info("screenshot after failed goto also failed: %s", e2)
            try:
                (self.debug_dir / f"{stem}.html").write_text(page.content())
            except Exception:
                pass
        except Exception:
            log.info("dump_failure itself failed", exc_info=True)   # never let debugging break the scrape


def embedded_json_blobs(html: str) -> list:
    """Pull JSON objects out of <script> tags (Next/Nuxt state, JSON-LD, inline bootstraps)."""
    out = []
    for m in re.finditer(r"<script[^>]*>(.*?)</script>", html or "", re.S | re.I):
        body = m.group(1).strip()
        if not body or len(body) < 20:
            continue
        candidates = [body]
        # window.__STATE__ = {...};
        for am in re.finditer(r"=\s*(\{.*\}|\[.*\])\s*;?\s*$", body, re.S):
            candidates.append(am.group(1))
        for c in candidates:
            try:
                out.append(json.loads(c))
                break
            except Exception:
                continue
    return out
