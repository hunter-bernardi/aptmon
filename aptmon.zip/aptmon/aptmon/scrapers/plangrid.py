"""Plan-level price grids - for sites that publish per-floor-plan prices but no unit numbers
(OneChicago: "CB1  2 Bed / 2 Bath  1,746 SF  $9,822" or "$6,236-6,606").

Each plan becomes a pseudo-unit "PLAN CB1" priced at the low end of its range. A plan that stops
showing a price goes off-market like a leased unit would.
"""
from __future__ import annotations

import logging
import re
from urllib.parse import urljoin

from bs4 import BeautifulSoup

from ..fetch import Fetcher
from ..models import Unit, norm_unit, parse_int, parse_price

log = logging.getLogger("aptmon.plangrid")

# plan code, then (within a short, $-free window) beds, baths, sq ft, then a price or price range
PLAN_RE = re.compile(
    r"\b(?P<plan>[A-Z]{1,3}\d{1,2}[A-Z]?)\b[^$\n]{0,60}?"
    r"(?P<beds>Studio|\d)(?:\s*Bed(?:room)?s?)?[^$\n]{0,40}?(?P<baths>\d(?:\.5)?)\s*Bath"
    r"[^$\n]{0,40}?(?P<sqft>[\d,]{3,5})\s*(?:SF|Sq\.?\s*Ft\.?|sq\s*ft)"
    r"[^$\n]{0,40}?\$\s?(?P<lo>[\d,]{4,6})(?:\s*[-–]\s*\$?\s?(?P<hi>[\d,]{4,6}))?", re.I)
PLAN_CODE_RE = re.compile(r"\b([A-Z]{1,3}\d{1,2}[A-Z]?)\b", re.I)
PDF_HREF_RE = re.compile(r"\.pdf(?:\?|$)", re.I)


def _pdf_map(soup, base: str) -> dict[str, str]:
    """Sites like OneChicago publish floor plans as PDFs only, keyed by filename or the plan code
    printed on the same card, e.g. ".../OneChicagoApts-CA8.pdf" or a "Download" link next to "CA8"."""
    out: dict[str, str] = {}
    for a in soup.find_all("a", href=PDF_HREF_RE):
        href = a["href"]
        fname_m = PLAN_CODE_RE.search(href.rsplit("/", 1)[-1].rsplit(".", 1)[0])
        code = fname_m.group(1).upper() if fname_m else None
        if not code:
            card = a
            for _ in range(4):
                card = card.parent
                if card is None:
                    break
                m = PLAN_CODE_RE.search(card.get_text(" ", strip=True))
                if m:
                    code = m.group(1).upper()
                    break
        if code:
            out.setdefault(code, urljoin(base, href))
    return out


def units_from_text(text: str, key: str, url: str, prefixes: list[str] | None = None) -> list[Unit]:
    out: dict[str, Unit] = {}
    for m in PLAN_RE.finditer(text):
        plan = m.group("plan").upper()
        if prefixes and not any(plan.startswith(p.upper()) for p in prefixes):
            continue
        beds = 0.0 if m.group("beds").lower() == "studio" else float(m.group("beds"))
        lo = parse_price(m.group("lo"))
        if not lo:
            continue
        u = Unit(key, f"PLAN {norm_unit(plan)}", lo, beds=beds, baths=float(m.group("baths")),
                 sqft=parse_int(m.group("sqft")), plan=plan, url=url, source="plan_grid",
                 extra={"price_high": parse_price(m.group("hi"))} if m.group("hi") else {})
        out.setdefault(u.unit, u)
    return list(out.values())


def scrape(key: str, bcfg: dict, f: Fetcher) -> list[Unit]:
    url = bcfg["plans_url"]
    html = f.render(url, wait_ms=4000).html          # JS-built grid on some sites; the browser handles both
    soup = BeautifulSoup(html, "lxml")
    # one line per block element so a plan's fields stay together and neighbours don't bleed in
    text = soup.get_text("\n", strip=True)
    text = re.sub(r"\n(?=[^\n]{0,40}(?:Bed|Bath|SF|Sq|\$))", " ", text)   # re-join a card's fields
    units = units_from_text(text, key, url, bcfg.get("plan_prefixes"))
    pdfs = _pdf_map(soup, url)                        # these sites publish PDF floor plans, no images
    for u in units:
        pdf = pdfs.get((u.plan or "").upper())
        if pdf:
            u.extra["plan_pdf_url"] = pdf
    log.info("%s: %d floor plans with prices", key, len(units))
    return units
