"""Related Rentals (relatedrentals.com) - The Row Fulton Market.

Listing cards look like:
  <a href=".../the-row-fulton-market/2-bedroom-2-bath-56123">
     The Row Fulton Market West Loop  2 Bedroom, 2 Bath  Price: 5,650  Available: 11/06  VIEW UNIT</a>
The trailing number is Related's listing id; the detail page title carries the residence number:
  "2 Bedroom, 2 Bath Apartment #3706 at The Row Fulton Market"
"""
from __future__ import annotations

import logging
import re
from urllib.parse import urljoin

from bs4 import BeautifulSoup

from ..fetch import Fetcher
from ..models import Unit, norm_unit, parse_available, parse_beds, parse_int, parse_price
from .generic import units_from_json

log = logging.getLogger("aptmon.related")

CARD_RE = re.compile(
    r"(?P<type>Studio|Convertible|Junior\s*1|\d\s*Bedroom(?:\s*\+\s*Den)?)\s*,?\s*(?P<baths>[\d.]+)\s*Bath"
    r".*?Price:?\s*\$?(?P<price>[\d,]{4,7})"
    r"(?:.*?Available:?\s*(?P<avail>[\d/]+|Now|Immediately))?", re.I | re.S)
TITLE_UNIT_RE = re.compile(r"(?:Apartment|Residence|Unit)\s*#\s*([A-Z0-9-]+)", re.I)
SQFT_RE = re.compile(r"([\d,]{3,5})\s*(?:sq\.?\s*ft|sf|square feet)", re.I)
PDF_HREF_RE = re.compile(r"\.pdf(?:\?|$)", re.I)


def cards_from_html(html: str, key: str, base: str, slug: str) -> dict[str, Unit]:
    soup = BeautifulSoup(html, "lxml")
    out: dict[str, Unit] = {}
    for a in soup.find_all("a", href=re.compile(rf"/{re.escape(slug)}/[^/?#]*-(\d+)/?$")):
        text = a.get_text(" ", strip=True)
        m = CARD_RE.search(text)
        if not m:
            # some layouts put the text next to (not inside) the link
            parent = a.find_parent(["article", "li", "div"])
            m = CARD_RE.search(parent.get_text(" ", strip=True)) if parent else None
        if not m:
            continue
        href = urljoin(base, a["href"])
        listing_id = re.search(r"-(\d+)/?$", href).group(1)
        out[listing_id] = Unit(
            key, f"L{listing_id}", parse_price(m.group("price")),
            beds=parse_beds(m.group("type")), baths=float(m.group("baths")),
            available=parse_available(m.group("avail")) if m.group("avail") else None,
            url=href, source="related_card", extra={"listing_id": listing_id},
        )
    return out


def sqft_from_json(payloads: list, listing_ids: set[str]) -> dict[str, int]:
    """Related doesn't print sq ft, but its search API records sometimes carry it: {listing id: sqft}."""
    from .generic import AREA_KEYS, first
    out: dict[str, int] = {}

    def visit(o, depth=0):
        if depth > 12:
            return
        if isinstance(o, dict):
            lid = next((str(o[k]) for k in ("id", "listing_id", "listingId", "unit_id", "unitId")
                        if k in o and str(o[k]) in listing_ids), None)
            if lid:
                sq = parse_int(first(o, AREA_KEYS))
                if sq and 300 <= sq <= 6000:
                    out[lid] = sq
            for v in o.values():
                visit(v, depth + 1)
        elif isinstance(o, list):
            for v in o:
                visit(v, depth + 1)

    visit(payloads)
    return out


def enrich_from_detail(u: Unit, f: Fetcher) -> None:
    """Swap the listing id for the real residence number and add sq ft."""
    try:
        html = f.get_html(u.url)
    except Exception as e:  # detail page is nice-to-have
        log.info("detail fetch failed %s: %s", u.url, e)
        return
    soup = BeautifulSoup(html, "lxml")
    title = (soup.title.get_text(" ", strip=True) if soup.title else "") + " " + \
            " ".join(h.get_text(" ", strip=True) for h in soup.find_all(["h1", "h2"])[:3])
    m = TITLE_UNIT_RE.search(title) or TITLE_UNIT_RE.search(soup.get_text(" ", strip=True)[:6000])
    if m:
        u.unit = norm_unit(m.group(1))
    sq = SQFT_RE.search(soup.get_text(" ", strip=True))
    if sq:
        u.sqft = parse_int(sq.group(1))
    pdf_a = soup.find("a", href=PDF_HREF_RE)               # Related only publishes PDF floor plans, no images
    if pdf_a and pdf_a.get("href"):
        u.extra["plan_pdf_url"] = urljoin(u.url, pdf_a["href"])


def _load_everything(page):
    """Click 'Load more' / scroll until the result count stops growing."""
    last = -1
    for _ in range(15):
        n = page.locator("a[href*='-']").count()
        if n == last:
            break
        last = n
        page.mouse.wheel(0, 20000)
        page.wait_for_timeout(1200)
        for label in ("Load More", "LOAD MORE", "Show More", "View More"):
            btn = page.get_by_text(label, exact=False)
            if btn.count():
                try:
                    btn.first.click(timeout=2000)
                    page.wait_for_timeout(1500)
                except Exception:
                    pass


def scrape(key: str, bcfg: dict, f: Fetcher, wanted_beds: list | None = None,
           known_units: dict | None = None) -> list[Unit]:
    base, slug = bcfg["site"], bcfg["slug"]
    cards: dict[str, Unit] = {}
    payloads: list = []

    # 1) full search results (JS-rendered) + any JSON it loads
    try:
        r = f.render(bcfg["search_url"], wait_ms=4000, interact=_load_everything)
        payloads = [d for _, d in r.json_payloads]
        cards.update(cards_from_html(r.html, key, base, slug))
        if not cards:
            js = units_from_json([d for _, d in r.json_payloads], key, source="related_json")
            for u in js:
                cards[u.unit] = u
    except Exception as e:
        log.warning("%s: search page failed: %s", key, e)

    # 2) the building page (server-rendered; only shows a few, but never needs JS)
    try:
        cards.update({k: v for k, v in cards_from_html(f.get_html(base + bcfg["building_path"]), key, base, slug).items()
                      if k not in cards})
    except Exception as e:
        log.warning("%s: building page failed: %s", key, e)

    for lid, sq in sqft_from_json(payloads, set(cards)).items():
        cards[lid].sqft = cards[lid].sqft or sq

    # 3) residence numbers + sq ft from detail pages, only for bed counts we track
    known_units = known_units or {}
    for lid, u in cards.items():
        if wanted_beds and u.beds is not None and u.beds not in wanted_beds:
            continue
        cached = known_units.get(lid)
        if cached:                       # listing id -> unit # never changes; skip the request
            u.unit, u.sqft = cached["unit"], u.sqft or cached.get("sqft")
            continue
        if u.url:
            enrich_from_detail(u, f)
    return list(cards.values())
