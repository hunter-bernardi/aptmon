"""SightMap (Engrain) scraper - Wolf Point East and Foundry both embed a SightMap.

The embed hydrates from sightmap.com JSON (units[] + floor_plans[] with bedroom_count),
so we load the embed in a headless browser and parse whatever JSON it pulls.
"""
from __future__ import annotations

import logging
import re

from ..fetch import Fetcher, embedded_json_blobs
from ..models import Unit, norm_unit, parse_beds, parse_int, parse_price
from .generic import units_from_json

log = logging.getLogger("aptmon.sightmap")


def scrape(key: str, bcfg: dict, f: Fetcher) -> list[Unit]:
    url = bcfg["sightmap_embed"]
    r = f.render(url, wait_ms=5000, json_filter=lambda u: "sightmap" in u or "engrain" in u)
    payloads = [d for _, d in r.json_payloads] + embedded_json_blobs(r.html)
    units = units_from_json(payloads, key, source="sightmap")      # links are added in links.finalize
    log.info("%s: sightmap json -> %d units (%d payloads)", key, len(units), len(r.json_payloads))
    return units


# ---------------- fallback: Entrata floor-plan grid (plan-level "From" price) ----------------
def entrata_floorplans(key: str, bcfg: dict, f: Fetcher) -> list[Unit]:
    """Wolf Point East server-renders /floor-plans/?pagenumber=N with one card per plan.
    Tracks the per-plan 'Base Rent From' price as pseudo-units named 'PLAN B4'."""
    from bs4 import BeautifulSoup

    out: dict[str, Unit] = {}
    for page in range(1, 6):
        html = f.get_html(f"{bcfg['site']}/floor-plans/?bedroom=&availability=&sqft=&max-price=&pagenumber={page}")
        soup = BeautifulSoup(html, "lxml")
        found = 0
        for h in soup.find_all(["h2", "h3"]):
            name = h.get_text(strip=True)
            card = h.find_parent(["div", "li", "article"])
            if not card or not re.fullmatch(r"[A-Z]{1,3}-?\d{1,2}[A-Z]?", name):
                continue
            text = card.get_text(" ", strip=True)
            price = parse_price(re.search(r"From:?\s*(\$[\d,]+)", text).group(1)) if re.search(r"From:?\s*\$[\d,]+", text) else None
            if not price:
                continue
            beds = parse_beds(text)
            m = re.search(r"(\d)\s*Bed", text)
            beds = float(m.group(1)) if m else beds
            sqft = parse_int(re.search(r"(\d{3,4})\s*SQ", text, re.I).group(1)) if re.search(r"\d{3,4}\s*SQ", text, re.I) else None
            link = card.find("a", href=re.compile(r"/floor-plans/\d+"))
            u = Unit(key, f"PLAN {norm_unit(name)}", price, beds=beds, sqft=sqft, plan=name,
                     url=link["href"] if link else bcfg["site"], source="entrata_plan")
            out[u.unit] = u
            found += 1
        if not found:
            break
    return list(out.values())
