"""Per-unit links and floor-plan lookups, applied to every building after scraping.

Config keys (all optional, per building):
  unit_url           template for a unit's link, e.g. "{site}/floor-plans/{plan_provider_id}/{unit}/"
                     placeholders: site, unit, plan, plan_provider_id, plan_url
  unit_url_fallback  used when the template can't be filled (e.g. "{site}/floor-plans")
  plan_index_url     page listing every floor plan as a link; used to find {plan_url} and to recover a
  plan_href_re       unit's plan from its sq ft when the listing data doesn't name the plan
"""
from __future__ import annotations

import logging
import re
import string
from urllib.parse import urljoin

from bs4 import BeautifulSoup

from ..fetch import Fetcher
from ..models import Unit, parse_int

log = logging.getLogger("aptmon.links")

SQFT_RE = re.compile(r"([\d,]{3,5})\s*(?:sq\.?\s*f(?:ee)?t|sqft|sf\b|square feet)", re.I)
BEDS_RE = re.compile(r"\b(\d)\s*Bed", re.I)


def plan_index(html: str, base: str, href_re: str) -> dict[str, dict]:
    """{plan name (upper): {"url", "beds", "sqft"}} from a floor-plan index page."""
    soup = BeautifulSoup(html or "", "lxml")
    out: dict[str, dict] = {}
    for a in soup.find_all("a", href=re.compile(href_re)):
        name = a.get_text(" ", strip=True)
        card, text = a, ""
        for _ in range(6):                                  # climb to the card holding name/beds/sq ft
            card = card.parent
            if card is None:
                break
            text = card.get_text(" ", strip=True)
            if SQFT_RE.search(text) or BEDS_RE.search(text):
                h = card.find(["h1", "h2", "h3", "h4", "h5"])
                if h and (not name or len(name) > 12):
                    name = h.get_text(" ", strip=True)
                break
        if not name or len(name) > 24:
            continue
        sq = SQFT_RE.search(text)
        bd = BEDS_RE.search(text)
        out.setdefault(name.upper(), {"url": urljoin(base, a["href"]),
                                      "sqft": parse_int(sq.group(1)) if sq else None,
                                      "beds": float(bd.group(1)) if bd else None})
    return out


def _fill(template: str, fields: dict) -> str | None:
    names = [n for _, n, _, _ in string.Formatter().parse(template) if n]
    if any(not fields.get(n) for n in names):
        return None
    return template.format(**fields)


def finalize(units: list[Unit], bcfg: dict, f: Fetcher) -> None:
    if not units:
        return
    plans: dict[str, dict] = {}
    if bcfg.get("plan_index_url"):
        try:
            plans = plan_index(f.get_html(bcfg["plan_index_url"]), bcfg["plan_index_url"],
                               bcfg.get("plan_href_re", r"floor-?plans?"))
        except Exception as e:                              # links are nice-to-have, never fatal
            log.info("plan index %s failed: %s", bcfg["plan_index_url"], e)
    for u in units:
        if not u.plan and u.sqft and plans:                 # recover plan from a unique sq ft match
            hits = [n for n, p in plans.items() if p["sqft"] == u.sqft and (u.beds is None or p["beds"] in (None, u.beds))]
            if len(hits) == 1:
                u.plan = hits[0]
        fields = {"site": (bcfg.get("site") or "").rstrip("/"), "unit": u.unit, "plan": u.plan,
                  "plan_provider_id": (u.extra or {}).get("plan_provider_id"),
                  "plan_url": plans.get((u.plan or "").upper(), {}).get("url")}
        url = _fill(bcfg["unit_url"], fields) if bcfg.get("unit_url") else None
        if url:
            u.url = url
        elif not u.url and bcfg.get("unit_url_fallback"):
            u.url = _fill(bcfg["unit_url_fallback"], fields)
