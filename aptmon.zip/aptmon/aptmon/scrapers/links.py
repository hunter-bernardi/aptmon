"""Per-unit links and floor-plan lookups, applied to every building after scraping.

Config keys (all optional, per building):
  unit_url           template for a unit's link, e.g. "{site}/floor-plans/{plan_provider_id}/{unit}/"
                     placeholders: site, unit, plan, plan_provider_id, plan_url
  unit_url_fallback  used when the template can't be filled (e.g. "{site}/floor-plans")
  plan_index_url     page listing every floor plan as a link; used to find {plan_url} and to recover a
  plan_href_re       unit's plan from its sq ft when the listing data doesn't name the plan
  plan_image_page    template for a per-plan page to visit just for its floor-plan diagram, e.g.
                     "{site}/floor-plans/{plan_provider_id}/" (placeholders: site, plan_provider_id) -
                     used when the diagram doesn't live on plan_index_url itself (e.g. Wolf Point East)
"""
from __future__ import annotations

import logging
import re
import string
from urllib.parse import urljoin

from bs4 import BeautifulSoup

from ..fetch import Fetcher
from ..models import Unit, parse_int

log = logging.getLogger("aptmon.links")

SQFT_RE = re.compile(r"([\d,]{3,5})\s*(?:sq\.?\s*f(?:ee)?t|sqft|sf\b|square feet)", re.I)
BEDS_RE = re.compile(r"\b(\d)\s*Bed", re.I)
IMG_HINT_RE = re.compile(r"floor.?plan", re.I)
PDF_HREF_RE = re.compile(r"\.pdf(?:\?|$)", re.I)


def _card_image(card, base: str) -> str | None:
    """Best-effort floor-plan diagram within a card: prefer an <img> whose alt/src says so,
    else fall back to the card's only image (a single image on a plan card is usually the diagram,
    never picked when there are several - that's ambiguous with lifestyle photos)."""
    if card is None:
        return None
    imgs = [img for img in card.find_all("img") if img.get("src") or img.get("data-src")]
    if not imgs:
        return None
    hinted = [img for img in imgs if IMG_HINT_RE.search((img.get("alt") or "") + " " + (img.get("src") or ""))]
    pick = hinted[0] if hinted else (imgs[0] if len(imgs) == 1 else None)
    if pick is None:
        return None
    return urljoin(base, pick.get("src") or pick.get("data-src"))


def _card_pdf(card, base: str) -> str | None:
    if card is None:
        return None
    a = card.find("a", href=PDF_HREF_RE)
    return urljoin(base, a["href"]) if a else None


def plan_index(html: str, base: str, href_re: str) -> dict[str, dict]:
    """{plan name (upper): {"url", "beds", "sqft", "image", "pdf"}} from a floor-plan index page."""
    soup = BeautifulSoup(html or "", "lxml")
    out: dict[str, dict] = {}
    for a in soup.find_all("a", href=re.compile(href_re)):
        name = a.get_text(" ", strip=True)
        card, text = a, ""
        for _ in range(6):                                  # climb to the card holding name/beds/sq ft
            card = card.parent
            if card is None:
                break
            text = card.get_text(" ", strip=True)
            if SQFT_RE.search(text) or BEDS_RE.search(text):
                h = card.find(["h1", "h2", "h3", "h4", "h5"])
                if h and (not name or len(name) > 12):
                    name = h.get_text(" ", strip=True)
                break
        if not name or len(name) > 24:
            continue
        sq = SQFT_RE.search(text)
        bd = BEDS_RE.search(text)
        out.setdefault(name.upper(), {"url": urljoin(base, a["href"]),
                                      "sqft": parse_int(sq.group(1)) if sq else None,
                                      "beds": float(bd.group(1)) if bd else None,
                                      "image": _card_image(card, base),
                                      "pdf": _card_pdf(card, base)})
    return out


def _fetch_plan_image(f: Fetcher, url: str, plan: str | None = None) -> str | None:
    """Visit a dedicated per-plan page just for its floor-plan diagram (requires an alt/src hint,
    or a match on the plan name/code itself - a whole page has too many photos to safely guess
    from "the only image"). Always a full browser render, not a plain GET: these per-plan pages
    (e.g. Wolf Point East's Entrata floor-plan page) can hydrate their gallery client-side, so a
    plain requests.get() can come back >2000 bytes (passing get_html()'s "good enough" check) with
    a page shell that never got the real <img> - it looks like a normal page, not a fetch failure,
    so nothing here would otherwise catch it."""
    try:
        html = f.render(url, wait_ms=3000).html
    except Exception as e:
        log.info("plan image page %s failed: %s", url, e)
        return None
    soup = BeautifulSoup(html or "", "lxml")
    plan_re = re.compile(re.escape(plan), re.I) if plan else None
    fallback = None
    for img in soup.find_all("img"):
        src = img.get("src") or img.get("data-src")
        if not src:
            continue
        alt = img.get("alt") or ""
        if IMG_HINT_RE.search(alt + " " + src):
            return urljoin(url, src)
        if fallback is None and plan_re and (plan_re.search(alt) or plan_re.search(src)):
            fallback = urljoin(url, src)          # weaker signal - keep looking for a stronger hint first
    return fallback


def _fill(template: str, fields: dict) -> str | None:
    names = [n for _, n, _, _ in string.Formatter().parse(template) if n]
    if any(not fields.get(n) for n in names):
        return None
    return template.format(**fields)


def finalize(units: list[Unit], bcfg: dict, f: Fetcher) -> None:
    if not units:
        return
    plans: dict[str, dict] = {}
    if bcfg.get("plan_index_url"):
        try:
            plans = plan_index(f.get_html(bcfg["plan_index_url"]), bcfg["plan_index_url"],
                               bcfg.get("plan_href_re", r"floor-?plans?"))
        except Exception as e:                              # links are nice-to-have, never fatal
            log.info("plan index %s failed: %s", bcfg["plan_index_url"], e)
    image_page_cache: dict[str, str | None] = {}
    for u in units:
        if not u.plan and u.sqft and plans:                 # recover plan from a unique sq ft match
            hits = [n for n, p in plans.items() if p["sqft"] == u.sqft and (u.beds is None or p["beds"] in (None, u.beds))]
            if len(hits) == 1:
                u.plan = hits[0]
        fields = {"site": (bcfg.get("site") or "").rstrip("/"), "unit": u.unit, "plan": u.plan,
                  "plan_provider_id": (u.extra or {}).get("plan_provider_id"),
                  "plan_url": plans.get((u.plan or "").upper(), {}).get("url")}
        url = _fill(bcfg["unit_url"], fields) if bcfg.get("unit_url") else None
        if url:
            u.url = url
        elif not u.url and bcfg.get("unit_url_fallback"):
            u.url = _fill(bcfg["unit_url_fallback"], fields)

        # floor-plan diagram / PDF for the unit-detail panel - best effort, never fatal
        plan_info = plans.get((u.plan or "").upper()) if plans else None
        if plan_info and plan_info.get("image") and not u.extra.get("plan_image_url"):
            u.extra["plan_image_url"] = plan_info["image"]
        if plan_info and plan_info.get("pdf") and not u.extra.get("plan_pdf_url"):
            u.extra["plan_pdf_url"] = plan_info["pdf"]
        if not u.extra.get("plan_image_url") and bcfg.get("plan_image_page") and fields["plan_provider_id"]:
            page_url = _fill(bcfg["plan_image_page"], fields)
            if page_url:
                if page_url not in image_page_cache:
                    image_page_cache[page_url] = _fetch_plan_image(f, page_url, u.plan)
                if image_page_cache[page_url]:
                    u.extra["plan_image_url"] = image_page_cache[page_url]
