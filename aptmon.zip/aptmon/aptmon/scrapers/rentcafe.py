"""RentCafe / Yardi property sites - Lincoln Common.

/floorplans lists every plan with its bed count; each /floorplans/<slug> page server-renders an
"Available Units" block where every unit has an apply link like
  .../rentaloptions/<unitId>/<propertyId>?MoveInDate=...
We anchor on those apply links, then read unit #, rent, sq ft and date from the surrounding row.
"""
from __future__ import annotations

import logging
import re
from urllib.parse import urljoin

from bs4 import BeautifulSoup

from ..fetch import Fetcher
from ..models import Unit, norm_unit, parse_available, parse_beds, parse_int, parse_price

log = logging.getLogger("aptmon.rentcafe")

APPLY_RE = re.compile(r"rentaloptions/(\d+)/(\d+)|UnitId=(\d+)|unitId=(\d+)", re.I)
UNIT_NO_RE = re.compile(r"(?:Apartment|Apt\.?|Unit|Residence|#)\s*:?\s*#?\s*([A-Z]{0,2}\d?-?\d{3,4}[A-Z]?)\b", re.I)
BARE_UNIT_RE = re.compile(r"\b([A-Z]\d-\d{3,4}|\d{3,4}[A-Z]?)\b")
RENT_RE = re.compile(r"\$\s?[\d,]{4,7}(?:\.\d\d)?")
SQFT_RES = [re.compile(r"sq\.?\s*f(?:ee)?t\.?\s*:?\s*([\d,]{3,5})", re.I),                 # "Sq.Ft: 1,184"
            re.compile(r"(?<![\d-])([\d,]{3,5})\s*(?:sq\.?\s*ft|sqft|square feet)", re.I)]  # "1,184 sq ft"
DATE_RE = re.compile(r"\d{1,2}/\d{1,2}/\d{2,4}|Available\s*Now|\bImmediately\b", re.I)


def plan_links(html: str, base: str) -> list[tuple[str, str, float | None]]:
    """[(plan_name, url, beds)] from the /floorplans index."""
    soup = BeautifulSoup(html, "lxml")
    out, seen = [], set()
    for a in soup.find_all("a", href=re.compile(r"/floorplans/[^/?#]+/?$", re.I)):
        url = urljoin(base, a["href"])
        if url in seen:
            continue
        # climb to the card that holds the bed count
        card, beds, name = a, None, None
        for _ in range(6):
            card = card.parent
            if card is None:
                break
            text = card.get_text(" ", strip=True)
            if re.search(r"\b(Studio|\d\s*Bed)", text, re.I):
                m = re.search(r"\b(\d)\s*Bed", text, re.I)
                beds = float(m.group(1)) if m else (0.0 if re.search(r"studio", text, re.I) else None)
                h = card.find(["h2", "h3", "h4", "h5"])
                name = h.get_text(" ", strip=True) if h else None
                break
        seen.add(url)
        slug = url.rstrip("/").rsplit("/", 1)[-1]
        out.append((name or slug, url, beds))
    return out


def _row_for(anchor):
    """Smallest ancestor that contains a rent figure (i.e. the unit's row/card)."""
    node = anchor
    for _ in range(8):
        node = node.parent
        if node is None:
            return None
        if RENT_RE.search(node.get_text(" ", strip=True)):
            return node
    return None


def units_from_plan_page(html: str, key: str, url: str, plan: str | None, beds: float | None) -> list[Unit]:
    soup = BeautifulSoup(html, "lxml")
    if beds is None:
        txt = soup.get_text(" ", strip=True)
        m = re.search(r"\b(one|two|three|four|\d)[\s-]*bedroom apartment|\b(\d)\s*Bed\s*/", txt, re.I)
        beds = parse_beds(f"{m.group(1) or m.group(2)} bed") if m else None
    out: dict[str, Unit] = {}
    for a in soup.find_all("a", href=APPLY_RE):
        row = _row_for(a)
        if row is None:
            continue
        text = row.get_text(" ", strip=True)
        m = UNIT_NO_RE.search(text) or BARE_UNIT_RE.search(text)
        if not m:
            continue
        unit_no = norm_unit(m.group(1))
        rent = parse_price(RENT_RE.search(text).group(0))
        sq = next((m for m in (rx.search(text) for rx in SQFT_RES) if m), None)
        dm = DATE_RE.search(text.replace(a.get_text(" ", strip=True), " "))
        uid = next(g for g in APPLY_RE.search(a["href"]).groups() if g)
        out[unit_no] = Unit(key, unit_no, rent, beds=beds, sqft=parse_int(sq.group(1)) if sq else None,
                            plan=plan, available=parse_available(dm.group(0)) if dm else None,
                            url=url, source="rentcafe", extra={"rentcafe_unit_id": uid})
    return list(out.values())


def scrape(key: str, bcfg: dict, f: Fetcher, wanted_beds: list | None = None) -> list[Unit]:
    base = bcfg["site"]
    index = f.get_html(base + bcfg.get("floorplans_path", "/floorplans"))
    plans = plan_links(index, base)
    log.info("%s: %d floor plans on index", key, len(plans))
    units: list[Unit] = []
    for name, url, beds in plans:
        # only open plan pages that could hold a wanted bed count (unknown beds -> open it)
        if wanted_beds and beds is not None and beds not in wanted_beds:
            # still record that other-bed units exist so an empty 2BR result isn't read as breakage
            units.append(Unit(key, f"_PLAN_{name}", None, beds=beds, plan=name, source="rentcafe_index"))
            continue
        html = f.get_html(url)
        got = units_from_plan_page(html, key, url, name, beds)
        units.extend(got)
    return units
