"""Schema-agnostic extraction: find unit-like records inside any JSON payload.

Used as the fallback for every building and as the primary parser for RealPage/unknown widgets.
A record counts as a unit if it has a unit-number-ish key AND a price-ish key.
Floor-plan lists found in the same payloads are joined in to recover bed/bath counts.
"""
from __future__ import annotations

import json
from typing import Iterable

from ..models import Unit, norm_unit, parse_available, parse_beds, parse_int, parse_price

UNIT_KEYS = ("display_unit_number", "unit_number", "unitNumber", "UnitNumber", "unit_name", "unitName",
             "apartmentName", "ApartmentName", "apartment_number", "residence", "unit", "name", "label")
PRICE_KEYS = ("price", "display_price", "rent", "Rent", "min_price", "minRent", "MinRent", "rentAmount",
              "leasing_price", "starting_price", "startingPrice", "effectiveRent", "baseRent", "amount",
              "MinimumRent", "marketRent", "askingRent")
AREA_KEYS = ("area", "display_area", "sqft", "square_feet", "squareFeet", "SQFT", "sqFt", "size", "SquareFeet")
AVAIL_KEYS = ("available_on", "display_available_on", "availableDate", "AvailableDate", "available_date",
              "availability", "availableFrom", "moveInDate", "AvailableDateString")
BED_KEYS = ("bedroom_count", "bedrooms", "beds", "Beds", "bedroomCount", "numberOfBedrooms", "Bedrooms")
BATH_KEYS = ("bathroom_count", "bathrooms", "baths", "Baths", "bathroomCount", "numberOfBathrooms", "Bathrooms")
PLAN_ID_KEYS = ("floor_plan_id", "floorplan_id", "floorPlanId", "FloorplanId", "floorplanId", "planId")
PLAN_NAME_KEYS = ("floor_plan_name", "floorplan_name", "floorPlanName", "FloorplanName", "planName", "floor_plan")


URL_KEYS = ("unit_url", "detail_url", "url", "link", "apply_url", "apply_link", "lease_url")


def clean_plan(v) -> tuple[str | None, str | None]:
    """Floor-plan field -> (display name, provider id). SightMap sometimes hands back the plan as an
    object {"name": "B5", "provider_id": "1149158"} (or that object serialized as a string)."""
    if v is None:
        return None, None
    if isinstance(v, str) and v.strip().startswith("{"):
        try:
            v = json.loads(v)
        except ValueError:
            return v, None
    if isinstance(v, dict):
        name = first(v, ("name", "display_name", "label", "code"))
        pid = first(v, ("provider_id", "providerId", "external_id"))
        return (str(name) if name is not None else None), (str(pid) if pid is not None else None)
    return str(v), None


def first(d: dict, keys: Iterable[str]):
    for k in keys:
        if k in d and d[k] not in (None, "", [], {}):
            return d[k]
    return None


def walk(obj, depth=0):
    """Yield every list-of-dicts found anywhere in obj, with the key it lived under."""
    if depth > 12:
        return
    if isinstance(obj, dict):
        for k, v in obj.items():
            if isinstance(v, list) and v and all(isinstance(x, dict) for x in v[:5]):
                yield k, v
            yield from walk(v, depth + 1)
    elif isinstance(obj, list):
        for x in obj:
            yield from walk(x, depth + 1)


def _looks_like_plan(d: dict) -> bool:
    return first(d, BED_KEYS) is not None and "id" in d and first(d, ("unit_number", "display_unit_number")) is None


def collect_plans(payloads: list) -> dict:
    plans = {}
    for payload in payloads:
        for key, lst in walk(payload):
            if "plan" not in key.lower():
                continue
            for d in lst:
                if _looks_like_plan(d):
                    plans[str(d["id"])] = d
    return plans


def units_from_json(payloads: list, building: str, source: str = "json") -> list[Unit]:
    plans = collect_plans(payloads)
    found: dict[str, Unit] = {}
    for payload in payloads:
        for key, lst in walk(payload):
            if "plan" in key.lower() and not any(first(d, ("unit_number", "display_unit_number")) for d in lst[:3]):
                continue
            for d in lst:
                num = first(d, UNIT_KEYS)
                price = parse_price(first(d, PRICE_KEYS))
                if num is None or price is None or isinstance(num, (dict, list)):
                    continue
                unit_no = norm_unit(num)
                if not unit_no or len(unit_no) > 16 or not any(c.isdigit() for c in unit_no):
                    continue
                plan = None
                pid = first(d, PLAN_ID_KEYS)
                if pid is not None and str(pid) in plans:
                    plan = plans[str(pid)]
                beds = parse_beds(first(d, BED_KEYS))
                if beds is None and plan:
                    beds = parse_beds(first(plan, BED_KEYS))
                baths = first(d, BATH_KEYS) or (first(plan, BATH_KEYS) if plan else None)
                plan_name, provider_id = clean_plan(first(d, PLAN_NAME_KEYS))
                if plan:
                    p_name, p_pid = clean_plan(plan)
                    plan_name, provider_id = plan_name or p_name, provider_id or p_pid
                url = first(d, URL_KEYS)
                extra = {"plan_provider_id": provider_id} if provider_id else {}
                u = Unit(
                    building=building,
                    unit=unit_no,
                    price=price,
                    beds=beds,
                    baths=float(baths) if isinstance(baths, (int, float)) or (isinstance(baths, str) and baths.replace(".", "").isdigit()) else None,
                    sqft=parse_int(first(d, AREA_KEYS)),
                    plan=plan_name,
                    available=parse_available(first(d, AVAIL_KEYS)),
                    url=url if isinstance(url, str) and url.startswith("http") else None,
                    source=source,
                    extra=extra,
                )
                # keep the lowest price seen if the same unit appears in several payloads (lease terms)
                prev = found.get(unit_no)
                if prev is None or (u.price and prev.price and u.price < prev.price):
                    if prev:
                        u.beds = u.beds if u.beds is not None else prev.beds
                        u.sqft = u.sqft or prev.sqft
                        u.plan, u.url = u.plan or prev.plan, u.url or prev.url
                        u.extra = u.extra or prev.extra
                    found[unit_no] = u
    return list(found.values())
