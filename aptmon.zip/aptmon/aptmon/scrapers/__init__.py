"""Scraper registry + fallback chain."""
from __future__ import annotations

import logging

from ..fetch import Fetcher, embedded_json_blobs
from ..models import Unit
from . import generic, links, plangrid, related, rentcafe, sightmap

log = logging.getLogger("aptmon.scrapers")


def _generic_json(key, bcfg, f: Fetcher, **_):
    units = []
    for url in bcfg.get("fallback_urls", []):
        try:
            r = f.render(url, wait_ms=5000)
            units += generic.units_from_json([d for _, d in r.json_payloads] + embedded_json_blobs(r.html),
                                             key, source="generic_json")
        except Exception as e:
            log.warning("%s generic fallback %s failed: %s", key, url, e)
    return units


REGISTRY = {
    "sightmap": lambda k, b, f, **kw: sightmap.scrape(k, b, f),
    "entrata_floorplans": lambda k, b, f, **kw: sightmap.entrata_floorplans(k, b, f),
    "rentcafe": lambda k, b, f, **kw: rentcafe.scrape(k, b, f, wanted_beds=kw.get("wanted_beds")),
    "related": lambda k, b, f, **kw: related.scrape(k, b, f, wanted_beds=kw.get("wanted_beds"),
                                                   known_units=kw.get("known_units")),
    "generic_json": _generic_json,
    "plan_grid": lambda k, b, f, **kw: plangrid.scrape(k, b, f),
}


def scrape_building(key: str, bcfg: dict, f: Fetcher, **kw) -> tuple[list[Unit], str, list[str]]:
    """Run the primary scraper, then the fallback if the primary produced nothing.
    Returns (units incl. price-less evidence rows, scraper_used, errors)."""
    errors: list[str] = []
    for name in [bcfg.get("scraper"), bcfg.get("fallback")]:
        if not name:
            continue
        try:
            units = REGISTRY[name](key, bcfg, f, **kw)
        except Exception as e:  # keep going to the fallback
            log.exception("%s: scraper %s crashed", key, name)
            errors.append(f"{name}: {type(e).__name__}: {e}")
            continue
        if units:   # priced units, or price-less evidence rows proving the page parsed
            links.finalize([u for u in units if u.price], bcfg, f)
            return units, name, errors
        errors.append(f"{name}: found no listings")
    return [], "", errors
