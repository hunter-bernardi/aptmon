"""Scraper registry + fallback chain."""
from __future__ import annotations

import logging
import time

from ..fetch import Fetcher, embedded_json_blobs
from ..models import Unit
from . import generic, links, plangrid, related, rentcafe, sightmap

log = logging.getLogger("aptmon.scrapers")


def _generic_json(key, bcfg, f: Fetcher, **_):
    units = []
    for url in bcfg.get("fallback_urls", []):
        try:
            r = f.render(url, wait_ms=5000)
            units += generic.units_from_json([d for _, d in r.json_payloads] + embedded_json_blobs(r.html),
                                             key, source="generic_json")
        except Exception as e:
            log.warning("%s generic fallback %s failed: %s", key, url, e)
    return units


REGISTRY = {
    "sightmap": lambda k, b, f, **kw: sightmap.scrape(k, b, f),
    "entrata_floorplans": lambda k, b, f, **kw: sightmap.entrata_floorplans(k, b, f),
    "rentcafe": lambda k, b, f, **kw: rentcafe.scrape(k, b, f, wanted_beds=kw.get("wanted_beds")),
    "related": lambda k, b, f, **kw: related.scrape(k, b, f, wanted_beds=kw.get("wanted_beds"),
                                                   known_units=kw.get("known_units")),
    "generic_json": _generic_json,
    "plan_grid": lambda k, b, f, **kw: plangrid.scrape(k, b, f),
}


def scrape_building(key: str, bcfg: dict, f: Fetcher, **kw) -> tuple[list[Unit], str, list[str]]:
    """Run the primary scraper, then the fallback if the primary produced nothing.
    Returns (units incl. price-less evidence rows, scraper_used, errors).

    If BOTH the primary and fallback come back empty (no exception, no listings), the whole pair
    is retried up to twice more (3 attempts total, 20s apart) before giving up on the building for
    this run. A single scraper crashing (an exception) already falls through to the fallback with
    no retry - this is specifically for "everything loaded, found nothing."

    Confirmed (via a captured scrape-debug artifact) that for Foundry this isn't a page-load
    timing issue or a bot block - the page renders fine and the SightMap widget's own API call
    (sightmaps/<id>) comes back with real unit records but every price null, even after our
    existing network-idle wait. Its downstream pricing feed (SightMap -> Knock "doorway" ->
    RealPage) intermittently hasn't synced when we ask - the Knock leg returned a bare
    "property cannot be found" on one attempt and succeeded ~45s later with no code change on our
    end. That's a vendor-side sync race, not something a longer per-request wait fixes (we already
    saw it fail twice, ~45s apart, in the same run). More independent attempts, spaced further
    apart, is the only lever that plausibly helps - it doesn't guarantee a synced response, it just
    buys more chances at one before we give up and let the next scheduled run (2h later) catch it,
    which is what's been happening."""
    errors: list[str] = []
    names = [n for n in (bcfg.get("scraper"), bcfg.get("fallback")) if n]
    attempts = 3
    for attempt in range(1, attempts + 1):
        for name in names:
            try:
                units = REGISTRY[name](key, bcfg, f, **kw)
            except Exception as e:  # keep going to the fallback
                log.exception("%s: scraper %s crashed", key, name)
                errors.append(f"{name}: {type(e).__name__}: {e}")
                continue
            if units:   # priced units, or price-less evidence rows proving the page parsed
                links.finalize([u for u in units if u.price], bcfg, f)
                return units, name, errors
            errors.append(f"{name}: found no listings")
        if attempt < attempts and names:
            log.info("%s: every scraper came back empty (attempt %d/%d), retrying in 20s",
                     key, attempt, attempts)
            time.sleep(20)
    return [], "", errors
