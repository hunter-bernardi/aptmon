"""Local dashboard: Flask serves one page + a JSON API. Run with `aptmon dashboard`."""
from __future__ import annotations

import json
import threading
from pathlib import Path

from flask import Flask, jsonify, render_template, request

from ..analytics import all_units, building_index
from ..db import DB

_scrape_lock = threading.Lock()


def create_app(cfg: dict) -> Flask:
    app = Flask(__name__, template_folder=str(Path(__file__).parent / "templates"))
    db = DB(cfg["db_path"])

    @app.get("/")
    def index():
        return render_template("index.html")

    @app.get("/api/data")
    def data():
        units = all_units(db, cfg)
        idx = building_index(db, cfg, days=int(request.args.get("days", 180)))
        events = db.q("SELECT * FROM events WHERE kind NOT IN ('new') OR ts >= datetime('now','-7 days') "
                      "ORDER BY ts DESC, id DESC LIMIT 200")
        specials = {}
        for c in db.active_concessions():
            specials.setdefault(c["building"], []).append({"text": c["text"], "since": c["first_seen"]})
        status = {}
        for key, b in cfg["buildings"].items():
            if b.get("enabled") is False:
                continue
            st = db.last_status(key)
            status[key] = {"name": b.get("name", key), "neighborhood": b.get("neighborhood", ""),
                           "site": b.get("site"), "specials": specials.get(key, []), **(st or {})}
        last_run = db.one("SELECT * FROM runs WHERE finished IS NOT NULL ORDER BY id DESC LIMIT 1")
        return jsonify({"units": units, "index": idx, "events": events, "status": status,
                        "last_run": last_run, "scraping": _scrape_lock.locked(),
                        "bedrooms": cfg.get("bedrooms", [2]),
                        "flat_band": cfg.get("trend", {}).get("flat_band_per_week", 10)})

    @app.get("/api/history/<path:key>")
    def history(key):
        return jsonify({
            "prices": db.q("SELECT ts, price FROM prices WHERE key=? ORDER BY ts", key),
            "events": db.q("SELECT * FROM events WHERE key=? ORDER BY ts DESC", key),
        })

    @app.post("/api/scrape")
    def scrape_now():
        if _scrape_lock.locked():
            return jsonify({"started": False, "reason": "already running"}), 409

        def job():
            from ..monitor import run
            with _scrape_lock:
                run(cfg)

        threading.Thread(target=job, daemon=True).start()
        return jsonify({"started": True})

    @app.get("/api/export.csv")
    def export_csv():
        import csv
        import io
        units = all_units(db, cfg)
        cols = ["building_name", "unit", "status", "beds", "baths", "sqft", "plan", "price", "ppsf",
                "first_price", "chg_last", "chg_total", "chg_total_pct", "peak", "off_peak_pct",
                "n_drops", "slope_wk", "trend", "available", "days_listed", "first_seen", "last_seen", "url"]
        buf = io.StringIO()
        w = csv.DictWriter(buf, fieldnames=cols, extrasaction="ignore")
        w.writeheader()
        w.writerows(units)
        return buf.getvalue(), 200, {"Content-Type": "text/csv",
                                     "Content-Disposition": "attachment; filename=aptmon_units.csv"}

    return app
