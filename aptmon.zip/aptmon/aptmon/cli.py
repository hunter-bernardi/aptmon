"""aptmon - command line entry point.

  aptmon run [--if-due]      scrape all buildings, record prices, send drop alerts
  aptmon export-site site/   build the iPhone web app (static) from the database
  aptmon dashboard           open the sortable dashboard at http://127.0.0.1:8050
  aptmon doctor              scrape with debug dumps, print what each scraper found (no DB writes)
  aptmon test-notify         send a test alert through every enabled channel
  aptmon schedule            run daily at 7:00 on this Mac (launchd) / print a cron line
  aptmon demo                load 45 days of synthetic history into a separate demo DB
"""
from __future__ import annotations

import argparse
import logging
import os
import platform
import subprocess
import sys
from pathlib import Path

from . import config as config_mod


def _cfg(args):
    cfg = config_mod.load(args.config)
    if getattr(args, "db", None):
        cfg["db_path"] = args.db
    return cfg


def cmd_run(args):
    from .monitor import run
    cfg = _cfg(args)
    if args.if_due:
        from .db import DB
        from .site import is_due
        due, why = is_due(DB(cfg["db_path"]), cfg)
        print(f"schedule check: {why}")
        if not due:
            return 0
    summary = run(cfg, only=args.only, debug=args.debug, notify=not args.no_notify)
    for k, v in summary.items():
        if k.startswith("_"):
            continue
        status = "ok " if v["ok"] else "FAIL"
        print(f"[{status}] {cfg['buildings'][k]['name']:<16} tracked={v['tracked']:<3} seen={v['seen']:<4} "
              f"via={v['scraper'] or '-'} {' | '.join(v['errors'])}")
    n = summary["_events"]
    print(f"alerts: {n}" + (" (not sent: --no-notify)" if args.no_notify and n else ""))
    return 0 if all(v["ok"] for k, v in summary.items() if not k.startswith("_")) else 2


def cmd_doctor(args):
    from .fetch import Fetcher
    from .scrapers import scrape_building
    cfg = _cfg(args)
    f = Fetcher(cfg, debug=True)
    wanted = [float(b) for b in cfg["bedrooms"]]
    try:
        for key, b in cfg["buildings"].items():
            if args.only and key not in args.only:
                continue
            units, used, errs = scrape_building(key, b, f, wanted_beds=wanted)
            priced = [u for u in units if u.price]
            mine = [u for u in priced if u.beds in wanted]
            print(f"\n== {b['name']} ({key}) via {used or 'NOTHING'}")
            print(f"   listings seen: {len(units)}   priced: {len(priced)}   matching beds {cfg['bedrooms']}: {len(mine)}")
            for e in errs:
                print(f"   ! {e}")
            for u in sorted(mine, key=lambda u: u.price)[:args.show]:
                print(f"   #{u.unit:<8} ${u.price:>6,}  {u.sqft or '?':>5} sf  plan={u.plan or '-':<10} avail={u.available or '-'}  [{u.source}]")
            unk = [u for u in priced if u.beds is None]
            if unk:
                print(f"   ({len(unk)} priced listings had unknown bed count)")
    finally:
        f.close()
    print(f"\nRaw HTML/JSON saved under {cfg['debug_dir']}")


def cmd_dashboard(args):
    from .dashboard.app import create_app
    cfg = _cfg(args)
    app = create_app(cfg)
    url = f"http://{args.host}:{args.port}"
    print(f"Dashboard: {url}   (db: {cfg['db_path']})")
    if args.open:
        import threading
        import webbrowser
        threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    app.run(host=args.host, port=args.port, debug=False)


def cmd_test_notify(args):
    from .notify import Notifier
    cfg = _cfg(args)
    ok = Notifier(cfg).send("📉 Price drop (test)",
                            "Price drop: Wolf Point East #4207 $5,657 -> $5,495 (-$162, -2.9%) · B12\n"
                            "This is a test from aptmon.")
    print("sent" if ok else "no channel succeeded - check config.yaml notify.channels")


def cmd_due(args):
    from .db import DB
    from .site import is_due
    cfg = _cfg(args)
    due, why = is_due(DB(cfg["db_path"]), cfg)
    print(why)
    return 0 if due else 1


def cmd_export_site(args):
    from .site import export_site
    cfg = _cfg(args)
    out = export_site(cfg, args.out)
    print(f"Static site written to {out}/ (open index.html via any web server)")


def cmd_demo(args):
    from .demo import seed
    cfg = _cfg(args)
    path = args.db or str(Path(cfg["db_path"]).with_name("demo.db"))
    seed(path, cfg)
    print(f"Demo data written to {path}\nView it:  aptmon dashboard --db {path}")


def cmd_schedule(args):
    exe = sys.executable
    cfgp = os.path.abspath(args.config) if args.config else ""
    cmd = [exe, "-m", "aptmon", "run"] + (["--config", cfgp] if cfgp else [])
    hour, minute = (int(x) for x in args.at.split(":"))
    when = f"every {args.every}h" if args.every else f"daily at {hour:02d}:{minute:02d} (Mac local time; runs on wake if asleep)"
    home = config_mod.HOME
    home.mkdir(parents=True, exist_ok=True)
    if platform.system() == "Darwin" and not args.cron:
        label = "com.aptmon.monitor"
        plist = Path.home() / "Library/LaunchAgents" / f"{label}.plist"
        plist.parent.mkdir(parents=True, exist_ok=True)
        path_env = os.environ.get("PATH", "/usr/bin:/bin:/usr/sbin:/sbin")
        args_xml = "".join(f"<string>{a}</string>" for a in cmd)
        timing = (f"<key>StartInterval</key><integer>{int(args.every * 3600)}</integer>" if args.every else
                  f"<key>StartCalendarInterval</key><dict><key>Hour</key><integer>{hour}</integer>"
                  f"<key>Minute</key><integer>{minute}</integer></dict>")
        plist.write_text(f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>{label}</string>
  <key>ProgramArguments</key><array>{args_xml}</array>
  {timing}
  <key>WorkingDirectory</key><string>{os.getcwd()}</string>
  <key>EnvironmentVariables</key><dict><key>PATH</key><string>{path_env}</string></dict>
  <key>StandardOutPath</key><string>{home}/aptmon.log</string>
  <key>StandardErrorPath</key><string>{home}/aptmon.log</string>
</dict></plist>
""")
        subprocess.run(["launchctl", "unload", str(plist)], capture_output=True)
        r = subprocess.run(["launchctl", "load", str(plist)], capture_output=True, text=True)
        print(f"Installed {plist} ({when}; log: {home}/aptmon.log)" if r.returncode == 0
              else f"Wrote {plist} but launchctl said: {r.stderr.strip()}")
        print(f"Remove with: launchctl unload {plist} && rm {plist}")
    else:
        spec = f"0 */{max(1, int(args.every))} * * *" if args.every else f"{minute} {hour} * * *"
        line = f"{spec} cd {os.getcwd()} && {' '.join(cmd)} >> {home}/aptmon.log 2>&1"
        print("Add this line with `crontab -e`:\n\n" + line)


def main(argv=None):
    p = argparse.ArgumentParser(prog="aptmon", description="2BR price monitor for Chicago high-rises")
    p.add_argument("--config", help="path to config.yaml (default: ./config.yaml or ~/.aptmon/config.yaml)")
    p.add_argument("-v", "--verbose", action="store_true")
    sub = p.add_subparsers(dest="cmd", required=True)

    r = sub.add_parser("run", help="scrape, record, alert")
    r.add_argument("--only", nargs="*", help="building keys to scrape")
    r.add_argument("--debug", action="store_true", help="save raw HTML/JSON to debug_dir")
    r.add_argument("--no-notify", action="store_true")
    r.add_argument("--db")
    r.add_argument("--if-due", action="store_true",
                   help="only scrape if it's past run_at_hour (local) and today's run hasn't happened")
    r.set_defaults(fn=cmd_run)

    du = sub.add_parser("due", help="exit 0 if today's scheduled check hasn't run yet")
    du.set_defaults(fn=cmd_due)

    ex = sub.add_parser("export-site", help="build the static iPhone web app")
    ex.add_argument("out", nargs="?", default="site")
    ex.add_argument("--db")
    ex.set_defaults(fn=cmd_export_site)

    d = sub.add_parser("doctor", help="dry-run scrapers and show what they see")
    d.add_argument("--only", nargs="*")
    d.add_argument("--show", type=int, default=15)
    d.set_defaults(fn=cmd_doctor)

    s = sub.add_parser("dashboard", help="serve the dashboard")
    s.add_argument("--host", default="127.0.0.1")
    s.add_argument("--port", type=int, default=8050)
    s.add_argument("--db")
    s.add_argument("--open", action="store_true", help="open a browser tab")
    s.set_defaults(fn=cmd_dashboard)

    t = sub.add_parser("test-notify", help="send a test alert")
    t.set_defaults(fn=cmd_test_notify)

    sc = sub.add_parser("schedule", help="run automatically in the background")
    sc.add_argument("--at", default="07:00", help="daily run time, HH:MM local (default 07:00)")
    sc.add_argument("--every", type=float, default=None, help="instead of daily, run every N hours")
    sc.add_argument("--cron", action="store_true", help="print a crontab line instead of using launchd")
    sc.set_defaults(fn=cmd_schedule)

    dm = sub.add_parser("demo", help="seed a demo database with synthetic history")
    dm.add_argument("--db")
    dm.set_defaults(fn=cmd_demo)

    args = p.parse_args(argv)
    logging.basicConfig(level=logging.INFO if args.verbose else logging.WARNING,
                        format="%(asctime)s %(name)s %(levelname)s %(message)s")
    return args.fn(args) or 0


if __name__ == "__main__":
    sys.exit(main())
