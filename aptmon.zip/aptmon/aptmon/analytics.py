"""Trend math. Everything is computed on a daily series (last observed price each day, carried
forward), so scrape frequency doesn't bias the slope."""
from __future__ import annotations

import json
import statistics
from collections import defaultdict
from datetime import date, datetime, timedelta

from .db import DB
from .scrapers.generic import clean_plan


def _day(ts: str) -> date:
    return datetime.fromisoformat(ts.replace("Z", "")).date()


def daily_series(obs: list[tuple[str, int]], end: date | None = None) -> list[tuple[date, int]]:
    """[(ts, price)] -> [(day, price)] one point per day from first obs to `end`, carried forward."""
    if not obs:
        return []
    by_day: dict[date, int] = {}
    for ts, p in sorted(obs):
        by_day[_day(ts)] = p
    days = sorted(by_day)
    end = end or days[-1]
    out, d, cur = [], days[0], None
    while d <= end:
        cur = by_day.get(d, cur)
        out.append((d, cur))
        d += timedelta(days=1)
    return out


def ols_slope(points: list[tuple[float, float]]) -> float | None:
    n = len(points)
    if n < 2:
        return None
    mx = sum(x for x, _ in points) / n
    my = sum(y for _, y in points) / n
    sxx = sum((x - mx) ** 2 for x, _ in points)
    if sxx == 0:
        return None
    return sum((x - mx) * (y - my) for x, y in points) / sxx


def unit_metrics(obs: list[tuple[str, int]], cfg: dict, end: date | None = None) -> dict:
    tcfg = cfg.get("trend", {})
    window, band = tcfg.get("window_days", 30), tcfg.get("flat_band_per_week", 10)
    series = daily_series(obs, end)
    prices = [p for _, p in series]
    cur, first = prices[-1], prices[0]
    changes = [b - a for (_, a), (_, b) in zip(series, series[1:]) if b != a]
    distinct = [p for i, p in enumerate(prices) if i == 0 or p != prices[i - 1]]
    prev = distinct[-2] if len(distinct) > 1 else None
    recent = series[-window:]
    x0 = recent[0][0]
    slope_day = ols_slope([((d - x0).days, p) for d, p in recent])
    slope_wk = slope_day * 7 if slope_day is not None else None
    if len(distinct) == 1:
        trend = "flat" if len(series) >= 7 else "new"
    elif slope_wk is None or abs(slope_wk) < band:
        trend = "flat"
    else:
        trend = "down" if slope_wk < 0 else "up"
    peak = max(prices)
    last_change_day = None
    for (d0, a), (d1, b) in zip(series, series[1:]):
        if b != a:
            last_change_day = d1
    return {
        "price": cur, "first_price": first, "prev_price": prev,
        "chg_last": cur - prev if prev is not None else 0,
        "chg_total": cur - first, "chg_total_pct": (cur - first) / first if first else 0,
        "peak": peak, "low": min(prices), "off_peak_pct": (cur - peak) / peak if peak else 0,
        "n_drops": sum(1 for c in changes if c < 0), "n_raises": sum(1 for c in changes if c > 0),
        "slope_wk": round(slope_wk, 1) if slope_wk is not None else None,
        "trend": trend, "last_change": last_change_day.isoformat() if last_change_day else None,
        "spark": [p for _, p in series[-60:]],
    }


def all_units(db: DB, cfg: dict, include_off_market: bool = True) -> list[dict]:
    rows = db.q("SELECT * FROM units" + ("" if include_off_market else " WHERE status='active'"))
    obs = defaultdict(list)
    for r in db.q("SELECT key, ts, price FROM prices ORDER BY ts"):
        obs[r["key"]].append((r["ts"], r["price"]))
    today = datetime.utcnow().date()
    out = []
    for u in rows:
        if not obs.get(u["key"]):
            continue
        end = today if u["status"] == "active" else _day(u["off_market_at"] or u["last_seen"])
        m = unit_metrics(obs[u["key"]], cfg, end=max(end, _day(obs[u["key"]][-1][0])))
        b = cfg["buildings"].get(u["building"], {})
        first_seen = _day(u["first_seen"])
        last_day = today if u["status"] == "active" else _day(u["off_market_at"] or u["last_seen"])
        out.append({
            **{k: u[k] for k in ("key", "building", "unit", "beds", "baths", "sqft", "plan", "url",
                                 "available", "status", "first_seen", "last_seen")},
            "plan": clean_plan(u["plan"])[0],        # older rows stored SightMap's plan object as text
            "building_name": b.get("name", u["building"]),
            "neighborhood": b.get("neighborhood", ""),
            "extra": json.loads(u["extra"] or "{}"),
            "days_listed": (last_day - first_seen).days,
            "ppsf": round(m["price"] / u["sqft"], 2) if u["sqft"] else None,
            **m,
        })
    return out


def building_index(db: DB, cfg: dict, days: int = 180) -> dict:
    """Per building, per day: median ask, median $/sf, and a same-unit index
    (mean % change of each live unit vs. its own first ask - immune to mix shifts)."""
    units = {u["key"]: u for u in db.q("SELECT key, building, sqft, first_seen, status, off_market_at, last_seen FROM units")}
    obs = defaultdict(list)
    for r in db.q("SELECT key, ts, price FROM prices ORDER BY ts"):
        obs[r["key"]].append((r["ts"], r["price"]))
    today = datetime.utcnow().date()
    start = today - timedelta(days=days)
    per_b: dict[str, dict[date, list]] = defaultdict(lambda: defaultdict(list))
    for k, o in obs.items():
        u = units.get(k)
        if not u:
            continue
        end = today if u["status"] == "active" else _day(u["off_market_at"] or u["last_seen"])
        s = daily_series(o, end=max(end, _day(o[-1][0])))
        first = s[0][1]
        for d, p in s:
            if d >= start:
                per_b[u["building"]][d].append((p, p / u["sqft"] if u["sqft"] else None, p / first - 1))
    out = {}
    for b, byday in per_b.items():
        pts = []
        for d in sorted(byday):
            vals = byday[d]
            ppsf = [x[1] for x in vals if x[1]]
            pts.append({"d": d.isoformat(), "n": len(vals),
                        "median": statistics.median(x[0] for x in vals),
                        "ppsf": round(statistics.median(ppsf), 3) if ppsf else None,
                        "same_unit_pct": round(100 * statistics.mean(x[2] for x in vals), 2)})
        recent = pts[-cfg.get("trend", {}).get("window_days", 30):]
        sl = ols_slope([(i, p["same_unit_pct"]) for i, p in enumerate(recent)])
        out[b] = {"name": cfg["buildings"].get(b, {}).get("name", b), "series": pts,
                  "same_unit_slope_pct_wk": round(sl * 7, 2) if sl is not None else None}
    return out
