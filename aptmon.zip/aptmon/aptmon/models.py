"""Core data types."""
from __future__ import annotations

import re
from dataclasses import dataclass, field, asdict
from datetime import date, datetime
from typing import Optional

_PRICE_RE = re.compile(r"\$?\s*([\d]{1,3}(?:,\d{3})+|\d{3,6})(?:\.\d{1,2})?")
_DATE_RES = [
    (re.compile(r"(\d{4})-(\d{1,2})-(\d{1,2})"), "ymd"),
    (re.compile(r"(\d{1,2})/(\d{1,2})/(\d{2,4})"), "mdy"),
    (re.compile(r"(\d{1,2})/(\d{1,2})(?!/)"), "md"),
]


@dataclass
class Unit:
    """One listed apartment as seen in one scrape."""

    building: str                 # building key from config, e.g. "wolf_point_east"
    unit: str                     # normalized unit number ("3706", "A1-0711")
    price: Optional[int]          # asking rent, whole dollars / month
    beds: Optional[float] = None  # 0 = studio/convertible
    baths: Optional[float] = None
    sqft: Optional[int] = None
    plan: Optional[str] = None
    available: Optional[str] = None   # ISO date, or "now"
    url: Optional[str] = None
    source: str = ""              # which extractor produced it (for debugging)
    extra: dict = field(default_factory=dict)

    def key(self) -> str:
        return f"{self.building}:{self.unit}"

    def to_dict(self) -> dict:
        return asdict(self)


def norm_unit(raw) -> str:
    s = str(raw or "").strip()
    s = re.sub(r"^(?:apt\.?|apartment|unit|residence|res\.?|#)\s*", "", s, flags=re.I)
    s = s.lstrip("#").strip()
    return s.upper()


def parse_price(v) -> Optional[int]:
    """'$4,849.00', '4849', 4849.0, '$4,780 - $5,100' (takes first) -> 4849."""
    if v is None or v is False:
        return None
    if isinstance(v, (int, float)):
        return int(round(v)) if v > 0 else None
    m = _PRICE_RE.search(str(v))
    if not m:
        return None
    n = int(m.group(1).replace(",", ""))
    return n if 300 <= n <= 100_000 else None


def parse_int(v) -> Optional[int]:
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return int(v) if v > 0 else None
    m = re.search(r"([\d,]+)", str(v))
    if not m:
        return None
    try:
        n = int(m.group(1).replace(",", ""))
    except ValueError:
        return None
    return n or None


def parse_beds(v) -> Optional[float]:
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).lower()
    if any(w in s for w in ("studio", "convertible", "alcove")):
        return 0.0
    words = {"one": 1, "two": 2, "three": 3, "four": 4}
    for w, n in words.items():
        if re.search(rf"\b{w}[\s-]*(?:bed|br)", s):
            return float(n)
    m = re.search(r"(\d+(?:\.\d)?)\s*(?:bed|br|bd|bedroom)", s) or re.fullmatch(r"\s*(\d+(?:\.\d)?)\s*", s)
    return float(m.group(1)) if m else None


def parse_available(v, today: Optional[date] = None) -> Optional[str]:
    """Normalize availability to ISO date or 'now'."""
    if v is None or v == "":
        return None
    s = str(v).strip()
    if re.search(r"\b(now|immediate|today)\b", s, re.I):
        return "now"
    today = today or date.today()
    for rx, kind in _DATE_RES:
        m = rx.search(s)
        if not m:
            continue
        try:
            if kind == "ymd":
                d = date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
            elif kind == "mdy":
                y = int(m.group(3))
                y = y + 2000 if y < 100 else y
                d = date(y, int(m.group(1)), int(m.group(2)))
            else:  # month/day with no year -> next occurrence
                d = date(today.year, int(m.group(1)), int(m.group(2)))
                if (today - d).days > 60:
                    d = date(today.year + 1, d.month, d.day)
        except ValueError:
            continue
        return "now" if d <= today else d.isoformat()
    return s[:40]


def utcnow() -> str:
    return datetime.utcnow().replace(microsecond=0).isoformat() + "Z"
