"""Concession / move-in special detection.

Each run fetches a few pages per building (config `concession_urls`, default: the building's site),
pulls out sentences that read like a leasing special ("1 month free", "6 weeks free",
"Up to $3,000 in move-in bonuses", "look & lease"), and diffs them against what was active last run.
A special that wasn't there before -> "concession" event (push). One that disappears -> "concession_end".
"""
from __future__ import annotations

import logging
import re

from bs4 import BeautifulSoup

from .db import DB
from .fetch import Fetcher

log = logging.getLogger("aptmon.concessions")

NUM = r"(?:\d+(?:\.\d+)?|one|two|three|four|five|six|seven|eight|nine|ten|twelve|a|an|1st|first)"
PATTERNS = [
    rf"\b{NUM}\s*(?:\(\d+\)\s*)?(?:full\s+)?(?:weeks?|months?|mos?\.?)\s+(?:of\s+)?(?:free|rent[- ]free|off|on\s+us|complimentary)\b",
    r"\b(?:free|complimentary)\s+(?:rent|months?|weeks?)\b",
    r"\brent[- ]free\b",
    r"\bmove[- ]?in\s+(?:bonus(?:es)?|specials?|credits?|incentives?|savings|concessions?)\b",
    r"\blook\s*(?:&|and|n'?)\s*lease\b",
    r"\blease\s+(?:today|now|by\s+\w+)\s+(?:and|&)\s+(?:get|receive|save)\b",
    r"\$\s?[\d,]{3,6}\s+(?:off|in\s+(?:move[- ]?in\s+)?(?:bonus(?:es)?|credits?|savings|concessions?|gift\s+cards?))\b",
    r"\b(?:reduced|waived|no)\s+(?:security\s+)?(?:deposit|admin(?:istration)?\s+fee|application\s+fee|amenity\s+fee)\b",
    r"\bnet[- ]effective\b",
    r"\blimited[- ]time\s+(?:offer|special|pricing|incentive)\b",
    r"\bconcessions?\b",
]
SPECIAL_RE = re.compile("|".join(f"(?:{p})" for p in PATTERNS), re.I)
# boilerplate that trips the patterns without being an offer
IGNORE_RE = re.compile(r"cookie|privacy|equal housing|terms of use|pet[- ]free|smoke[- ]free|free wi-?fi|"
                       r"free parking for guests|concessions? (?:stand|area)", re.I)


def extract(html: str) -> list[str]:
    """Distinct concession sentences from one page."""
    soup = BeautifulSoup(html or "", "lxml")
    for t in soup(["script", "style", "noscript", "svg", "template"]):
        t.decompose()
    text = soup.get_text("\n", strip=True)
    found: dict[str, str] = {}
    for line in text.split("\n"):
        for sent in re.split(r"(?<=[.!?])\s+", line):
            s = re.sub(r"\s+", " ", sent).strip(" -–|•*")
            if not (8 <= len(s) <= 220) or not SPECIAL_RE.search(s) or IGNORE_RE.search(s):
                continue
            found.setdefault(normalize(s), s)
    return list(found.values())


def normalize(s: str) -> str:
    return re.sub(r"[^a-z0-9$]+", " ", s.lower()).strip()


# ---------------- net-effective-rent estimation ----------------
# Only ONE shape of concession converts into a trustworthy per-unit dollar figure: a stated free
# period ("1 month free", "6 weeks free"). That scales exactly with a given unit's own rent, so
# there's nothing to assume - the math is the same regardless of which unit you're looking at.
#
# A flat "$X off" / "up to $X in move-in bonuses" figure is deliberately NOT converted into a
# number, after actually checking rather than assuming: for Foundry specifically, three sources
# (the property's own site, Apartments.com, ApartmentList) all show "up to $3,000," a fourth
# (Zillow) shows a completely different offer ("up to 1.5 months free"), a fifth (a real Chicago
# leasing brokerage cross-listing the building) shows no special at all, and the leasing platform's
# own backend config - the system actually powering their live pricing widget - reports
# `leasingSpecialIsActive: False`, i.e. no special is currently configured as active in the system
# of record. With the sources disagreeing on both the number AND whether an offer is even live
# right now, no single figure is defensible from scraped ad copy alone - so a scraped dollar amount
# is left as a "$X" fact for you to read (it's still shown verbatim in the specials feed/dashboard
# banner) rather than turned into a rent number that could just as easily be wrong.
#
# The one way a flat dollar figure DOES get used: `confirmed_override()` below, for an amount a
# human has actually verified (e.g. called the leasing office) and entered into config.yaml per
# building/bed-count - see `buildings.<key>.concession_overrides` in config.example.yaml. That's
# not a guess from marketing text, it's a fact you checked, so it's treated differently.
_WORD_NUM = {"a": 1, "an": 1, "one": 1, "1st": 1, "first": 1, "two": 2, "three": 3, "four": 4,
             "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10, "twelve": 12}
_FREE_PERIOD_RE = re.compile(
    rf"\b({NUM})\s*(?:\(\d+\)\s*)?(?:full\s+)?(weeks?|months?|mos?\.?)\s+(?:of\s+)?"
    r"(?:free|rent[- ]free|off|on\s+us|complimentary)\b", re.I)


def _num(s: str) -> float:
    v = _WORD_NUM.get(s.lower())
    return float(v) if v is not None else float(s)


def parse_offer(text: str) -> dict | None:
    """One concession sentence -> {"kind": "weeks"|"months", "amount": float}, or None if it
    doesn't state a free-rent period we can convert into a discount with no guessing involved
    (a flat dollar figure, "reduced deposit," "look & lease" with no period attached, etc.)."""
    m = _FREE_PERIOD_RE.search(text)
    if m:
        kind = "weeks" if m.group(2).lower().startswith("w") else "months"
        return {"kind": kind, "amount": _num(m.group(1))}
    return None


def effective_rent(price: int | None, offers: list[str], lease_term_months: int = 12,
                   confirmed_amount: float | None = None) -> int | None:
    """`price` minus the single best currently-active concession, spread evenly over
    `lease_term_months`. Returns the effective monthly price, or None if there's no price and
    nothing to apply. A flat dollar figure scraped from marketing text never contributes on its
    own (see the module docstring for why) - `confirmed_amount` is the one exception, for a dollar
    figure a human has actually verified (e.g. by calling the leasing office), passed in by
    building/unit-type via config rather than guessed from ad copy. Nothing is summed - whichever
    single figure (a stated free period, or a confirmed dollar amount) is worth the most wins."""
    if not price:
        return None
    best_discount = float(confirmed_amount) if confirmed_amount else 0.0
    for text in offers or []:
        parsed = parse_offer(text)
        if not parsed:
            continue
        weekly_or_monthly_rent = price * 12 / 52 if parsed["kind"] == "weeks" else price
        discount = parsed["amount"] * weekly_or_monthly_rent
        best_discount = max(best_discount, discount)
    if best_discount <= 0:
        return None
    return round(price - best_discount / lease_term_months)


def confirmed_override(bcfg: dict, beds) -> float | None:
    """A human-verified flat-dollar concession for this building/bed-count, from
    `buildings.<key>.concession_overrides` in config.yaml (see config.example.yaml). Each entry is
    {beds: [2.0], amount: 3000, note: "..."} - beds omitted means it applies to every bed count."""
    best = None
    for ov in bcfg.get("concession_overrides") or []:
        if not ov.get("beds") or beds in ov["beds"]:
            best = max(best or 0, ov.get("amount") or 0)
    return best


def apply_effective_rent(units: list[dict], specials_by_building: dict, buildings_cfg: dict | None = None,
                         lease_term_months: int = 12) -> None:
    """Mutate each unit dict in place, adding eff_price (and eff_ppsf, when sqft is known) when its
    building currently has an active concession that converts into a number - either a stated free
    period, or a config-confirmed dollar override (see confirmed_override). The override only
    applies while the building has *some* active concession posted (so it stops the moment a
    "concession_end" is detected, without needing its own expiry date to maintain). Units with
    neither are left untouched."""
    buildings_cfg = buildings_cfg or {}
    offer_texts = {b: [s["text"] for s in specials] for b, specials in specials_by_building.items()}
    for u in units:
        b = u.get("building")
        confirmed = confirmed_override(buildings_cfg.get(b, {}), u.get("beds")) if offer_texts.get(b) else None
        eff = effective_rent(u.get("price"), offer_texts.get(b), lease_term_months, confirmed_amount=confirmed)
        if eff is not None:
            u["eff_price"] = eff
            if u.get("sqft"):
                u["eff_ppsf"] = round(eff / u["sqft"], 2)


def check_building(db: DB, f: Fetcher, key: str, bcfg: dict, ts: str) -> list[tuple[str, str]]:
    """Fetch the building's pages, update the concessions table, return [(kind, text)] changes."""
    urls = bcfg.get("concession_urls") or ([bcfg["site"]] if bcfg.get("site") else [])
    offers: dict[str, str] = {}
    fetched_any = False
    for url in urls:
        try:
            html = f.get_html(url)
        except Exception as e:
            log.info("%s concession page %s failed: %s", key, url, e)
            continue
        if html and len(html) > 2000:
            fetched_any = True
            for s in extract(html):
                offers.setdefault(normalize(s), s)
    if not fetched_any:            # an outage must not look like "the special ended"
        return []
    return db.sync_concessions(key, offers, ts)
