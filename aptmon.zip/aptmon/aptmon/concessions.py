"""Concession / move-in special detection.

Each run fetches a few pages per building (config `concession_urls`, default: the building's site),
pulls out sentences that read like a leasing special ("1 month free", "6 weeks free",
"Up to $3,000 in move-in bonuses", "look & lease"), and diffs them against what was active last run.
A special that wasn't there before -> "concession" event (push). One that disappears -> "concession_end".
"""
from __future__ import annotations

import logging
import re

from bs4 import BeautifulSoup

from .db import DB
from .fetch import Fetcher

log = logging.getLogger("aptmon.concessions")

NUM = r"(?:\d+(?:\.\d+)?|one|two|three|four|five|six|seven|eight|nine|ten|twelve|a|an|1st|first)"
PATTERNS = [
    rf"\b{NUM}\s*(?:\(\d+\)\s*)?(?:full\s+)?(?:weeks?|months?|mos?\.?)\s+(?:of\s+)?(?:free|rent[- ]free|off|on\s+us|complimentary)\b",
    r"\b(?:free|complimentary)\s+(?:rent|months?|weeks?)\b",
    r"\brent[- ]free\b",
    r"\bmove[- ]?in\s+(?:bonus(?:es)?|specials?|credits?|incentives?|savings|concessions?)\b",
    r"\blook\s*(?:&|and|n'?)\s*lease\b",
    r"\blease\s+(?:today|now|by\s+\w+)\s+(?:and|&)\s+(?:get|receive|save)\b",
    r"\$\s?[\d,]{3,6}\s+(?:off|in\s+(?:move[- ]?in\s+)?(?:bonus(?:es)?|credits?|savings|concessions?|gift\s+cards?))\b",
    r"\b(?:reduced|waived|no)\s+(?:security\s+)?(?:deposit|admin(?:istration)?\s+fee|application\s+fee|amenity\s+fee)\b",
    r"\bnet[- ]effective\b",
    r"\blimited[- ]time\s+(?:offer|special|pricing|incentive)\b",
    r"\bconcessions?\b",
]
SPECIAL_RE = re.compile("|".join(f"(?:{p})" for p in PATTERNS), re.I)
# boilerplate that trips the patterns without being an offer
IGNORE_RE = re.compile(r"cookie|privacy|equal housing|terms of use|pet[- ]free|smoke[- ]free|free wi-?fi|"
                       r"free parking for guests|concessions? (?:stand|area)", re.I)


def extract(html: str) -> list[str]:
    """Distinct concession sentences from one page."""
    soup = BeautifulSoup(html or "", "lxml")
    for t in soup(["script", "style", "noscript", "svg", "template"]):
        t.decompose()
    text = soup.get_text("\n", strip=True)
    found: dict[str, str] = {}
    for line in text.split("\n"):
        for sent in re.split(r"(?<=[.!?])\s+", line):
            s = re.sub(r"\s+", " ", sent).strip(" -–|•*")
            if not (8 <= len(s) <= 220) or not SPECIAL_RE.search(s) or IGNORE_RE.search(s):
                continue
            found.setdefault(normalize(s), s)
    return list(found.values())


def normalize(s: str) -> str:
    return re.sub(r"[^a-z0-9$]+", " ", s.lower()).strip()


def check_building(db: DB, f: Fetcher, key: str, bcfg: dict, ts: str) -> list[tuple[str, str]]:
    """Fetch the building's pages, update the concessions table, return [(kind, text)] changes."""
    urls = bcfg.get("concession_urls") or ([bcfg["site"]] if bcfg.get("site") else [])
    offers: dict[str, str] = {}
    fetched_any = False
    for url in urls:
        try:
            html = f.get_html(url)
        except Exception as e:
            log.info("%s concession page %s failed: %s", key, url, e)
            continue
        if html and len(html) > 2000:
            fetched_any = True
            for s in extract(html):
                offers.setdefault(normalize(s), s)
    if not fetched_any:            # an outage must not look like "the special ended"
        return []
    return db.sync_concessions(key, offers, ts)
