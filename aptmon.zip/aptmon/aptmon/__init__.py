"""aptmon - 2-bedroom rent monitor for Wolf Point East, The Foundry, Lincoln Common and The Row."""
__version__ = "0.1.0"
