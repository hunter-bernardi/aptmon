"""Synthetic history for previewing the dashboard. Runs the real diff/event pipeline on fake scrapes.
Numbers are made up (seeded near each building's published 2BR plan pricing) - never mixed into the real DB."""
from __future__ import annotations

import os
import random
from datetime import datetime, timedelta

from .db import DB
from .models import Unit
from .monitor import apply_results

SEED_UNITS = {
    "wolf_point_east": [("1804", "B4", 1128, 4849), ("2206", "B5", 1142, 4979), ("3107", "B6", 1145, 5799),
                        ("3512", "B7", 1192, 5698), ("4207", "B12", 1302, 5657), ("4411", "B16", 1471, 5828),
                        ("2604", "B4", 1128, 4925)],
    "foundry": [("1206", "B2", 990, 4780), ("1512", "B3", 1020, 4869), ("1808", "B4", 1020, 4856),
                ("2204", "B5", 1030, 5004), ("0906", "B2", 990, 4710)],
    "lincoln_common": [("A1-0711", "Sheffield", 1184, 6303), ("A2-0511", "Sheffield", 1184, 6323),
                       ("A1-1402", "Drummond", 1164, 6416), ("A2-1603", "Drummond", 1164, 6490)],
    "the_row": [("2105", "2 Bed, 2 Bath", 1210, 5650), ("2904", "2 Bed, 2 Bath", 1245, 5895),
                ("3702", "2 Bed, 2 Bath", 1321, 6950), ("1603", "2 Bed, 2 Bath", 1180, 5480)],
}
# per-building drift in $/day (negative = softening) so the index chart has shape
DRIFT = {"wolf_point_east": -3.5, "foundry": -1.2, "lincoln_common": 0.6, "the_row": -2.2}


def seed(path: str, cfg: dict, days: int = 45, rng_seed: int = 7):
    if os.path.exists(path):
        os.remove(path)
    rnd = random.Random(rng_seed)
    db = DB(path)
    now = datetime.utcnow().replace(microsecond=0)
    state = {b: {u[0]: {"plan": u[1], "sqft": u[2], "price": u[3], "live": rnd.random() < 0.8,
                        "start": rnd.randint(0, days // 2)} for u in us} for b, us in SEED_UNITS.items()}
    for day in range(days + 1):
        for hour in (9, 21):                              # two scrapes a day, ending "now"
            ts = (now - timedelta(days=days - day, hours=21 - hour)).isoformat() + "Z"
            run_id = db.start_run(ts)
            for b, units in state.items():
                out = []
                for num, s in units.items():
                    if day < s["start"] and not s["live"]:
                        continue
                    if hour == 9 and rnd.random() < 0.10:     # a repricing event
                        move = DRIFT[b] * rnd.uniform(4, 12) + rnd.choice([-1, 1]) * rnd.uniform(0, 40)
                        s["price"] = int(round((s["price"] + move) / 5) * 5)
                    if day > days * 0.6 and num in ("3512", "A2-1603") and day > s["start"] + 10:
                        continue                              # leased
                    out.append(Unit(b, num, s["price"], beds=2.0, baths=2.0, sqft=s["sqft"], plan=s["plan"],
                                    available="now" if rnd.random() < 0.5 else None,
                                    url=cfg["buildings"][b].get("site"), source="demo"))
                apply_results(db, cfg, run_id, b, out, "demo", [], ts)
            db.finish_run(run_id, ts, {"demo": True})
    return path
