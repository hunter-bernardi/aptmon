"""Static export for the hosted iPhone web app (GitHub Pages): index.html + data.json + PWA assets."""
from __future__ import annotations

import json
import os
import shutil
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from .analytics import all_units, building_index
from .concessions import apply_effective_rent
from .db import DB

DASH = Path(__file__).parent / "dashboard"


def build_data(db: DB, cfg: dict) -> dict:
    units = all_units(db, cfg)
    history = defaultdict(lambda: {"prices": [], "events": []})
    for r in db.q("SELECT key, ts, price FROM prices ORDER BY ts"):
        history[r["key"]]["prices"].append({"ts": r["ts"], "price": r["price"]})
    for r in db.q("SELECT * FROM events WHERE key IS NOT NULL AND kind IN ('drop','increase','relisted','off_market') "
                  "ORDER BY ts DESC"):
        history[r["key"]]["events"].append(r)
    specials = defaultdict(list)
    for c in db.active_concessions():
        specials[c["building"]].append({"text": c["text"], "since": c["first_seen"]})
    apply_effective_rent(units, specials, cfg["buildings"], cfg.get("lease_term_months", 12))
    status = {}
    for key, b in cfg["buildings"].items():
        if b.get("enabled") is False:
            continue
        st = db.last_status(key)
        status[key] = {"name": b.get("name", key), "neighborhood": b.get("neighborhood", ""),
                       "site": b.get("site"), "specials": specials.get(key, []), **(st or {})}
    repo = os.environ.get("GITHUB_REPOSITORY")
    return {
        "units": units,
        "index": building_index(db, cfg, days=180),
        "events": db.q("SELECT * FROM events WHERE kind != 'new' OR ts >= datetime('now','-7 days') "
                       "ORDER BY ts DESC, id DESC LIMIT 200"),
        "status": status,
        "last_run": db.one("SELECT * FROM runs WHERE finished IS NOT NULL ORDER BY id DESC LIMIT 1"),
        "scraping": False,
        "bedrooms": cfg.get("bedrooms", [2]),
        "flat_band": cfg.get("trend", {}).get("flat_band_per_week", 10),
        "history": {k: v for k, v in history.items() if v["prices"]},
        "actions_url": f"https://github.com/{repo}/actions/workflows/monitor.yml" if repo else None,
    }


def export_site(cfg: dict, out: str) -> Path:
    out_p = Path(out)
    out_p.mkdir(parents=True, exist_ok=True)
    db = DB(cfg["db_path"])
    (out_p / "data.json").write_text(json.dumps(build_data(db, cfg), default=str, separators=(",", ":")))
    html = (DASH / "templates" / "index.html").read_text()
    html = html.replace("<script>\nconst $ =", "<script>window.APTMON_STATIC = true;</script>\n<script>\nconst $ =", 1)
    (out_p / "index.html").write_text(html)
    shutil.copytree(DASH / "static", out_p / "static", dirs_exist_ok=True)
    shutil.copy(DASH / "static" / "sw.js", out_p / "sw.js")        # SW scope must be the site root
    (out_p / ".nojekyll").write_text("")
    return out_p


def is_due(db: DB, cfg: dict, now: datetime | None = None) -> tuple[bool, str]:
    """True once per local day, at/after run_at_hour. Lets a UTC cron fire twice (DST-proof) but scrape once."""
    tz = ZoneInfo(cfg.get("timezone", "America/Chicago"))
    now = (now or datetime.now(tz)).astimezone(tz)
    hour = int(cfg.get("run_at_hour", 7))
    if now.hour < hour:
        return False, f"{now:%H:%M %Z} is before {hour:02d}:00"
    for r in db.q("SELECT started FROM runs WHERE finished IS NOT NULL ORDER BY id DESC LIMIT 5"):
        started = datetime.fromisoformat(r["started"].replace("Z", "+00:00")).astimezone(tz)
        if started.date() == now.date() and started.hour >= hour:
            return False, f"already ran today at {started:%H:%M %Z}"
    return True, f"due ({now:%a %H:%M %Z})"
