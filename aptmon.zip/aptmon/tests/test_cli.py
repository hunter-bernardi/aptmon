import argparse

from aptmon import cli
from aptmon.notify import Notifier


def test_notify_deploy_sends_commit_message_and_files(tmp_path, monkeypatch):
    calls = []
    monkeypatch.setattr(Notifier, "send", lambda self, title, body: calls.append((title, body)) or True)
    args = argparse.Namespace(config=str(tmp_path / "none.yaml"), db=str(tmp_path / "t.db"),
                              message="Fix floor plan images", author="Hunter",
                              files="aptmon/scrapers/links.py")
    cli.cmd_notify_deploy(args)
    assert len(calls) == 1
    title, body = calls[0]
    assert "updated" in title.lower()
    assert "Fix floor plan images" in body and "Hunter" in body and "links.py" in body


def test_notify_deploy_respects_on_deploy_false(tmp_path, monkeypatch):
    cfgfile = tmp_path / "config.yaml"
    cfgfile.write_text("notify:\n  on_deploy: false\n")
    calls = []
    monkeypatch.setattr(Notifier, "send", lambda self, title, body: calls.append(1) or True)
    args = argparse.Namespace(config=str(cfgfile), db=str(tmp_path / "t.db"),
                              message="msg", author="", files="")
    cli.cmd_notify_deploy(args)
    assert calls == []                                          # disabled - never even tried to send
