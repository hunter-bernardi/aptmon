import json
from pathlib import Path

from aptmon.models import parse_available, parse_beds, parse_price
from aptmon.scrapers import generic, related, rentcafe

FX = Path(__file__).parent / "fixtures"
BASE = "https://www.lincolncommonapartments.com"


def test_parsers():
    assert parse_price("$6,303.00") == 6303
    assert parse_price("Price:9,950") == 9950
    assert parse_price(4849.0) == 4849
    assert parse_price("Call for details") is None
    assert parse_beds("2 Bedroom, 2 Bath") == 2
    assert parse_beds("Two bedroom apartment") == 2
    assert parse_beds("Convertible, 1 Bath") == 0
    assert parse_available("Available Now") == "now"
    assert parse_available("2099-10-01") == "2099-10-01"


def test_rentcafe_index_and_plan():
    plans = rentcafe.plan_links((FX / "lc_floorplans.html").read_text(), BASE)
    by = {n: (u, b) for n, u, b in plans}
    assert by["Sheffield"] == (BASE + "/floorplans/sheffield", 2.0)
    assert by["Drummond"][1] == 2.0
    assert by["Altgeld"][1] == 0.0 and by["Deming"][1] == 1.0
    assert "Wilton" not in by                       # no link -> nothing to open
    units = rentcafe.units_from_plan_page((FX / "lc_sheffield.html").read_text(), "lincoln_common",
                                          BASE + "/floorplans/sheffield", "Sheffield", None)
    u = {x.unit: x for x in units}
    assert set(u) == {"A1-0711", "A2-0511"}
    assert u["A1-0711"].price == 6303 and u["A1-0711"].sqft == 1184 and u["A1-0711"].beds == 2
    assert u["A1-0711"].available == "now"
    assert u["A2-0511"].price == 6323 and u["A2-0511"].available == "2026-10-15"
    assert u["A2-0511"].extra["rentcafe_unit_id"] == "15403776"


def test_related_cards_and_detail(monkeypatch):
    cards = related.cards_from_html((FX / "related_building.html").read_text(), "the_row",
                                    "https://www.relatedrentals.com", "the-row-fulton-market")
    assert set(cards) == {"56304", "56111", "56233", "56150"}
    assert cards["56111"].beds == 2 and cards["56111"].price == 5650 and cards["56111"].baths == 2
    assert cards["56150"].price == 6125 and cards["56150"].available == "now"
    assert cards["56233"].beds == 0 and cards["56304"].beds == 3

    class F:
        def get_html(self, url):
            return (FX / "related_detail.html").read_text()
    u = cards["56111"]
    related.enrich_from_detail(u, F())
    assert u.unit == "2105" and u.sqft == 1210


def test_sightmap_json():
    payload = json.loads((FX / "sightmap.json").read_text())
    units = {u.unit: u for u in generic.units_from_json([payload], "wolf_point_east", "sightmap")}
    assert set(units) == {"1804", "2206", "907", "512"}      # fee rows ignored
    assert units["1804"].beds == 2 and units["1804"].price == 4849 and units["1804"].sqft == 1128
    assert units["1804"].plan == "B4" and units["1804"].available == "2026-10-01"
    assert units["2206"].price == 4979                          # falls back to display_price
    assert units["907"].beds == 1 and units["512"].beds == 0
