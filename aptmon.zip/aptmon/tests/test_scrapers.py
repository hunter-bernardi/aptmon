import json
from pathlib import Path

from aptmon.models import Unit, parse_available, parse_beds, parse_price
from aptmon.scrapers import generic, links, plangrid, related, rentcafe
from aptmon import concessions

FX = Path(__file__).parent / "fixtures"
BASE = "https://www.lincolncommonapartments.com"


def test_parsers():
    assert parse_price("$6,303.00") == 6303
    assert parse_price("Price:9,950") == 9950
    assert parse_price(4849.0) == 4849
    assert parse_price("Call for details") is None
    assert parse_beds("2 Bedroom, 2 Bath") == 2
    assert parse_beds("Two bedroom apartment") == 2
    assert parse_beds("Convertible, 1 Bath") == 0
    assert parse_available("Available Now") == "now"
    assert parse_available("2099-10-01") == "2099-10-01"


def test_rentcafe_index_and_plan():
    plans = rentcafe.plan_links((FX / "lc_floorplans.html").read_text(), BASE)
    by = {n: (u, b) for n, u, b, _ in plans}
    assert by["Sheffield"] == (BASE + "/floorplans/sheffield", 2.0)
    assert by["Drummond"][1] == 2.0
    assert by["Altgeld"][1] == 0.0 and by["Deming"][1] == 1.0
    assert "Wilton" not in by                       # no link -> nothing to open
    units = rentcafe.units_from_plan_page((FX / "lc_sheffield.html").read_text(), "lincoln_common",
                                          BASE + "/floorplans/sheffield", "Sheffield", None)
    u = {x.unit: x for x in units}
    assert set(u) == {"A1-0711", "A2-0511"}
    assert u["A1-0711"].price == 6303 and u["A1-0711"].sqft == 1184 and u["A1-0711"].beds == 2
    assert u["A1-0711"].available == "now"
    assert u["A2-0511"].price == 6323 and u["A2-0511"].available == "2026-10-15"
    assert u["A2-0511"].extra["rentcafe_unit_id"] == "15403776"


def test_related_cards_and_detail(monkeypatch):
    cards = related.cards_from_html((FX / "related_building.html").read_text(), "the_row",
                                    "https://www.relatedrentals.com", "the-row-fulton-market")
    assert set(cards) == {"56304", "56111", "56233", "56150"}
    assert cards["56111"].beds == 2 and cards["56111"].price == 5650 and cards["56111"].baths == 2
    assert cards["56150"].price == 6125 and cards["56150"].available == "now"
    assert cards["56233"].beds == 0 and cards["56304"].beds == 3

    class F:
        def get_html(self, url):
            return (FX / "related_detail.html").read_text()
    u = cards["56111"]
    related.enrich_from_detail(u, F())
    assert u.unit == "2105" and u.sqft == 1210


def test_sightmap_json():
    payload = json.loads((FX / "sightmap.json").read_text())
    units = {u.unit: u for u in generic.units_from_json([payload], "wolf_point_east", "sightmap")}
    assert set(units) == {"1804", "2206", "907", "512"}      # fee rows ignored
    assert units["1804"].beds == 2 and units["1804"].price == 4849 and units["1804"].sqft == 1128
    assert units["1804"].plan == "B4" and units["1804"].available == "2026-10-01"
    assert units["2206"].price == 4979                          # falls back to display_price
    assert units["907"].beds == 1 and units["512"].beds == 0


def test_sightmap_plan_object_and_provider_id():
    """Real SightMap payloads hand the plan back as an object; it used to render as raw JSON."""
    payload = {"units": [
        {"unit_number": "2704", "price": 4845, "area": 1142, "floor_plan": {"name": "B5", "provider_id": "1149158"}},
        {"unit_number": "3204", "price": 4949, "area": 1142, "floor_plan": '{"name":"B5","provider_id":"1149158"}'},
    ]}
    units = {u.unit: u for u in generic.units_from_json([payload], "wolf_point_east", "sightmap")}
    for n in ("2704", "3204"):
        assert units[n].plan == "B5" and units[n].extra["plan_provider_id"] == "1149158"
    assert generic.clean_plan('{"name":"B10","provider_id":"1149144"}') == ("B10", "1149144")


def test_unit_links():
    wpe = {"site": "https://www.wolfpointeast.com", "unit_url": "{site}/floor-plans/{plan_provider_id}/{unit}/",
           "unit_url_fallback": "{site}/floor-plans/"}
    a = Unit("wolf_point_east", "2704", 4845, plan="B5", extra={"plan_provider_id": "1149158"})
    b = Unit("wolf_point_east", "999", 4000)                       # no provider id -> fallback
    links.finalize([a, b], wpe, None)
    assert a.url == "https://www.wolfpointeast.com/floor-plans/1149158/2704/"
    assert b.url == "https://www.wolfpointeast.com/floor-plans/"

    idx = """<div><a href="/floor-plans/?floorplanId=13"><h2>B4</h2></a><p>2 Bed / 2 Bath 1,030 Sq. Ft.</p>
               <img src="/img/B4.png" alt="B4"></div>
             <div><a href="/floor-plans/?floorplanId=14"><h2>B5</h2></a><p>2 Bed / 2 Bath 1,120 Sq. Ft.</p></div>"""
    plans = links.plan_index(idx, "https://www.livefoundrychicago.com/floor-plans", r"floorplanId=\d+")
    assert plans["B4"] == {"url": "https://www.livefoundrychicago.com/floor-plans/?floorplanId=13", "sqft": 1030,
                           "beds": 2.0, "image": "https://www.livefoundrychicago.com/img/B4.png", "pdf": None}
    assert plans["B5"]["image"] is None                            # no image on that card -> no guessing

    class F:
        def get_html(self, url):
            return idx
    foundry = {"site": "https://www.livefoundrychicago.com", "plan_index_url": "https://www.livefoundrychicago.com/floor-plans",
               "plan_href_re": r"floorplanId=\d+", "unit_url": "{plan_url}", "unit_url_fallback": "{site}/floor-plans"}
    c = Unit("foundry", "502", 4900, beds=2.0, sqft=1030)          # plan unknown -> matched by sq ft
    d = Unit("foundry", "1216", 4900, sqft=999)                    # no match -> floor-plans page
    links.finalize([c, d], foundry, F())
    assert c.plan == "B4" and c.url.endswith("floorplanId=13")
    assert c.extra["plan_image_url"] == "https://www.livefoundrychicago.com/img/B4.png"   # carried from the plan card
    assert d.url == "https://www.livefoundrychicago.com/floor-plans"
    assert "plan_image_url" not in d.extra


def test_unit_links_plan_image_page():
    """Wolf Point East: the diagram isn't on the plan_index card - fetch its own per-plan page,
    once per plan (not once per unit), and only trust an alt/src that says 'floor plan'."""
    page = ('<img src="/hero.jpg" alt="Lobby"><img src="https://cdn.example.com/b5.jpg" '
            'alt="Apartment type B5 floorplan">')
    fetched = []

    class Rendered:
        def __init__(self, html):
            self.html = html

    class F:
        def render(self, url, wait_ms=None):
            fetched.append(url)
            return Rendered(page)

    wpe = {"site": "https://www.wolfpointeast.com", "unit_url": "{site}/floor-plans/{plan_provider_id}/{unit}/",
           "plan_image_page": "{site}/floor-plans/{plan_provider_id}/"}
    a = Unit("wolf_point_east", "2704", 4845, plan="B5", extra={"plan_provider_id": "1149158"})
    b = Unit("wolf_point_east", "3204", 4949, plan="B5", extra={"plan_provider_id": "1149158"})
    links.finalize([a, b], wpe, F())
    assert a.extra["plan_image_url"] == "https://cdn.example.com/b5.jpg"
    assert b.extra["plan_image_url"] == "https://cdn.example.com/b5.jpg"
    assert fetched == ["https://www.wolfpointeast.com/floor-plans/1149158/"]      # cached - one fetch for both units


def test_unit_links_plan_image_page_falls_back_to_plan_name_match():
    """Some per-plan pages never say "floor plan" anywhere (image is just named/alt'd by the plan
    code) - fall back to matching the unit's own plan name/code, but only after no image says
    "floor plan" at all, since that hint is the stronger signal."""
    page = '<img src="/hero.jpg" alt="Lobby"><img src="https://cdn.example.com/a3.png" alt="A3">'

    class Rendered:
        def __init__(self, html):
            self.html = html

    class F:
        def render(self, url, wait_ms=None):
            return Rendered(page)

    wpe = {"site": "https://www.wolfpointeast.com", "plan_image_page": "{site}/floor-plans/{plan_provider_id}/"}
    a = Unit("wolf_point_east", "1104", 4200, plan="A3", extra={"plan_provider_id": "998"})
    links.finalize([a], wpe, F())
    assert a.extra["plan_image_url"] == "https://cdn.example.com/a3.png"


def test_rentcafe_plan_sqft_carried_to_units():
    idx = """<div class="card"><h3>Sheffield</h3><p>2 Bed / 2 Bath \u20221,184 Sq. Ft.</p>
             <a href="/floorplans/sheffield">View</a></div>"""
    plans = rentcafe.plan_links(idx, BASE)
    assert plans[0][0] == "Sheffield" and plans[0][2] == 2.0 and plans[0][3] == 1184
    page = """<table><tr><td>Apartment: #A1-0711</td><td>$6,303</td>
              <td><a href="https://x/rentaloptions/15403510/123">Apply</a></td></tr></table>"""
    (u,) = rentcafe.units_from_plan_page(page, "lincoln_common", BASE + "/floorplans/sheffield", "Sheffield", 2.0, 1184)
    assert u.unit == "A1-0711" and u.sqft == 1184


def test_rentcafe_plan_image():
    page = ("""<img src="/hero.jpg" alt="Lobby">"""
            """<img src="https://resource.rentcafe.com/img/sheffield-fp.png" alt="Sheffield floor plan">"""
            """<table><tr><td>Apartment: #A1-0711</td><td>$6,303</td>
              <td><a href="https://x/rentaloptions/15403510/123">Apply</a></td></tr></table>""")
    (u,) = rentcafe.units_from_plan_page(page, "lincoln_common", BASE + "/floorplans/sheffield", "Sheffield", 2.0, 1184)
    assert u.extra["plan_image_url"] == "https://resource.rentcafe.com/img/sheffield-fp.png"


def test_related_detail_pdf():
    class F:
        def get_html(self, url):
            return ('<html><body><h1>2 Bedroom, 2 Bath Apartment #2105 at The Row Fulton Market</h1>'
                    '<p>1,210 sq ft</p><a href="/sites/default/files/TheRow_Floor21-25.pdf">Download floorplan</a>'
                    '</body></html>')
    u = Unit("the_row", "L56111", 5650, url="https://www.relatedrentals.com/apartment-rentals/x/2-bed-56111")
    related.enrich_from_detail(u, F())
    assert u.unit == "2105" and u.sqft == 1210
    assert u.extra["plan_pdf_url"] == "https://www.relatedrentals.com/sites/default/files/TheRow_Floor21-25.pdf"


def test_plan_grid_onechicago():
    text = ("CB1\n2 Bed / 2 Bath\n1,746 SF\n$9,822\nCB4 2 Bed / 2 Bath 1,561 SF $8,442\n"
            "WB1 2 Bed / 2 Bath 1,096 SF $6,236-6,606\nCA8 1 Bed + Den / 1.5 Bath 1,177 SF $6,279-6,489\n"
            "CC2 3 Bed / 3 Bath 2,100 SF\nCall for details\nCS1 Studio / 1 Bath 540 SF $2,995")
    import re
    text = re.sub(r"\n(?=[^\n]{0,40}(?:Bed|Bath|SF|Sq|\$))", " ", text)
    units = {u.plan: u for u in plangrid.units_from_text(text, "one_chicago", "https://liveonechicago.com/floor-plans", ["C"])}
    assert set(units) == {"CB1", "CB4", "CA8", "CS1"}               # W* is 23 West; CC2 has no price
    assert units["CB1"].price == 9822 and units["CB1"].beds == 2 and units["CB1"].sqft == 1746
    assert units["CA8"].price == 6279 and units["CA8"].extra["price_high"] == 6489 and units["CA8"].baths == 1.5
    assert units["CS1"].beds == 0 and units["CB1"].unit == "PLAN CB1"


def test_plan_grid_pdf_map():
    from bs4 import BeautifulSoup
    html = ('<div class="card"><h3>CB1</h3><a href="/floorPlans/OneChicagoApts-CB1.pdf">Download</a></div>'
            '<div class="card"><h3>CA8</h3><a href="/floorPlans/OneChicagoApts-CA8.pdf">Download</a></div>')
    soup = BeautifulSoup(html, "lxml")
    pdfs = plangrid._pdf_map(soup, "https://liveonechicago.com/floor-plans")
    assert pdfs["CB1"] == "https://liveonechicago.com/floorPlans/OneChicagoApts-CB1.pdf"
    assert pdfs["CA8"] == "https://liveonechicago.com/floorPlans/OneChicagoApts-CA8.pdf"

    text = "CB1 2 Bed / 2 Bath 1,746 SF $9,822"
    units = plangrid.units_from_text(text, "one_chicago", "https://liveonechicago.com/floor-plans", ["C"])
    assert units[0].plan == "CB1" and "plan_pdf_url" not in units[0].extra   # pdf attach happens in scrape()


def test_concession_extract():
    html = """<html><head><script>var x = "1 month free";</script></head><body>
      <nav>Specials</nav><div class="banner">Lease Today and Get Up to $3,000 in Move-In Bonuses!</div>
      <p>Get 6 weeks free on select 2 bedrooms. Terms apply.</p><p>Smoke-free building. Pet-free floors available.</p>
      <p>We are a pet friendly community.</p><footer>Equal Housing Opportunity</footer></body></html>"""
    got = concessions.extract(html)
    assert "Lease Today and Get Up to $3,000 in Move-In Bonuses!" in got
    assert "Get 6 weeks free on select 2 bedrooms." in got
    assert len(got) == 2                                            # script text + boilerplate ignored
