from datetime import date

import pytest

from aptmon import config
from aptmon.analytics import all_units, building_index, unit_metrics
from aptmon.db import DB
from aptmon.models import Unit
from aptmon.monitor import apply_results


@pytest.fixture
def env(tmp_path):
    cfg = config.load(str(tmp_path / "none.yaml"))
    cfg["db_path"] = str(tmp_path / "t.db")
    return cfg, DB(cfg["db_path"])


def U(unit, price, beds=2.0, sqft=1100, b="foundry"):
    return Unit(b, unit, price, beds=beds, sqft=sqft, plan="B2")


def step(db, cfg, ts, units, b="foundry"):
    rid = db.start_run(ts)
    ids = apply_results(db, cfg, rid, b, units, "test", [], ts)
    return [db.one("SELECT * FROM events WHERE id=?", i) for i in ids]


def test_drop_new_offmarket_relist(env):
    cfg, db = env
    assert step(db, cfg, "2026-09-01T12:00:00Z", [U("1206", 4780), U("1512", 4869), U("305", 2700, beds=1)]) == []
    assert {u["unit"] for u in db.q("SELECT unit FROM units")} == {"1206", "1512"}   # 1BR ignored
    ev = step(db, cfg, "2026-09-02T12:00:00Z", [U("1206", 4700), U("1512", 4869)])
    assert len(ev) == 1 and ev[0]["kind"] == "drop" and ev[0]["old_price"] == 4780 and ev[0]["new_price"] == 4700
    assert "-$80" in ev[0]["message"]
    ev = step(db, cfg, "2026-09-03T12:00:00Z", [U("1206", 4750)])                   # raise, 1512 leased
    assert [e["kind"] for e in ev] == ["increase", "off_market"]                     # raises notify too now
    assert db.get_unit("foundry:1512")["status"] == "off_market"
    step(db, cfg, "2026-09-04T12:00:00Z", [U("1206", 4750), U("1512", 4800)])
    assert db.get_unit("foundry:1512")["status"] == "active"
    kinds = [e["kind"] for e in db.q("SELECT kind FROM events ORDER BY id")]
    assert kinds.count("off_market") == 1 and "relisted" in kinds and "increase" in kinds


def test_broken_scrape_does_not_delist_and_alerts_once(env):
    cfg, db = env
    step(db, cfg, "2026-09-01T12:00:00Z", [U("1206", 4780)])
    ev = step(db, cfg, "2026-09-02T12:00:00Z", [])
    assert [e["kind"] for e in ev] == ["broken"]
    assert db.get_unit("foundry:1206")["status"] == "active"
    assert step(db, cfg, "2026-09-03T12:00:00Z", []) == []                          # no repeat alert
    ev = step(db, cfg, "2026-09-04T12:00:00Z", [U("1206", 4780)])
    assert [e["kind"] for e in ev] == ["recovered"]


def test_zero_2br_but_page_parsed_is_not_broken(env):
    cfg, db = env
    step(db, cfg, "2026-09-01T12:00:00Z", [U("1206", 4780)])
    ev = step(db, cfg, "2026-09-02T12:00:00Z", [U("305", 2700, beds=1)])
    assert [e["kind"] for e in ev] == ["off_market"] and db.get_unit("foundry:1206")["status"] == "off_market"


def test_min_drop_threshold(env):
    cfg, db = env
    cfg["notify"]["min_drop_dollars"] = 50
    step(db, cfg, "2026-09-01T12:00:00Z", [U("1206", 4780)])
    assert step(db, cfg, "2026-09-02T12:00:00Z", [U("1206", 4760)]) == []
    assert len(step(db, cfg, "2026-09-03T12:00:00Z", [U("1206", 4700)])) == 1


def test_related_listing_id_rename(env):
    cfg, db = env
    u = Unit("the_row", "L56111", 5650, beds=2.0, extra={"listing_id": "56111"})
    step(db, cfg, "2026-09-01T12:00:00Z", [u], b="the_row")
    u2 = Unit("the_row", "2105", 5600, beds=2.0, extra={"listing_id": "56111"})
    ev = step(db, cfg, "2026-09-02T12:00:00Z", [u2], b="the_row")
    assert [e["kind"] for e in ev] == ["drop"]
    assert db.get_unit("the_row:L56111") is None
    assert len(db.q("SELECT * FROM prices WHERE key='the_row:2105'")) == 2
    assert db.listing_map("the_row") == {"56111": {"unit": "2105", "sqft": None}}


def test_trend_metrics():
    cfg = config.DEFAULTS
    obs = [(f"2026-08-{d:02d}T12:00:00Z", 5000 - 10 * d) for d in range(1, 29)]
    m = unit_metrics(obs, cfg, end=date(2026, 8, 28))
    assert m["trend"] == "down" and m["slope_wk"] == -70.0
    assert m["chg_total"] == -270 and m["n_drops"] == 27 and m["off_peak_pct"] < 0
    flat = unit_metrics([("2026-08-01T00:00:00Z", 5000), ("2026-08-20T00:00:00Z", 5000)], cfg, end=date(2026, 8, 20))
    assert flat["trend"] == "flat" and flat["chg_last"] == 0
    new = unit_metrics([("2026-08-01T00:00:00Z", 5000)], cfg, end=date(2026, 8, 2))
    assert new["trend"] == "new"


def test_index_same_unit(env):
    cfg, db = env
    step(db, cfg, "2026-09-01T12:00:00Z", [U("1", 5000), U("2", 4000)])
    step(db, cfg, "2026-09-02T12:00:00Z", [U("1", 4900), U("2", 4000)])
    idx = building_index(db, cfg, days=100000)["foundry"]["series"]
    d2 = next(p for p in idx if p["d"] == "2026-09-02")
    assert d2["same_unit_pct"] == -1.0 and d2["median"] == 4450 and d2["n"] == 2
    rows = all_units(db, cfg)
    assert {r["unit"]: r["chg_total"] for r in rows} == {"1": -100, "2": 0}


def test_evening_scrape_buckets_to_chicago_day_not_utc(env):
    """Central time is UTC-5 (CDT) / UTC-6 (CST), so any run from ~7pm-midnight local already
    reads as tomorrow in UTC. Bucketing by the raw UTC date (the old bug) showed that evening's
    data - and any "since <date>" label built from it - as happening a day early."""
    cfg, db = env
    # 2026-09-21T00:29:00Z is 2026-09-20 19:29 CDT (UTC-5) - still Sep 20 in Chicago
    step(db, cfg, "2026-09-21T00:29:00Z", [U("1", 5000)])
    idx = building_index(db, cfg, days=100000)["foundry"]["series"]
    assert idx[0]["d"] == "2026-09-20"   # bucketed to Sep 20 Chicago, not Sep 21 UTC (series may run
                                          # past that day too, since "active" carries forward to real today)
    rows = all_units(db, cfg)
    assert rows[0]["first_seen"] == "2026-09-21T00:29:00Z"   # raw storage stays UTC - only bucketing/display shifts


def test_daily_gate_once_after_7am_chicago(env):
    from datetime import datetime
    from zoneinfo import ZoneInfo
    from aptmon.site import is_due
    cfg, db = env
    tz = ZoneInfo("America/Chicago")
    assert is_due(db, cfg, datetime(2026, 9, 21, 6, 55, tzinfo=tz))[0] is False     # before 7
    assert is_due(db, cfg, datetime(2026, 9, 21, 7, 2, tzinfo=tz))[0] is True       # 12:02 UTC cron
    rid = db.start_run("2026-09-21T12:02:00Z"); db.finish_run(rid, "2026-09-21T12:05:00Z", {})
    assert is_due(db, cfg, datetime(2026, 9, 21, 8, 1, tzinfo=tz))[0] is False      # 13:00 UTC cron skips
    assert is_due(db, cfg, datetime(2026, 9, 22, 7, 1, tzinfo=tz))[0] is True       # next day
    # winter (CST): the 12:00 UTC trigger is 6 AM local -> skip; 13:00 UTC is 7 AM -> run
    assert is_due(db, cfg, datetime(2026, 12, 1, 12, 0, tzinfo=ZoneInfo("UTC")))[0] is False
    assert is_due(db, cfg, datetime(2026, 12, 1, 13, 0, tzinfo=ZoneInfo("UTC")))[0] is True


def test_export_site(env, tmp_path):
    import json
    from aptmon.site import export_site
    cfg, db = env
    step(db, cfg, "2026-09-01T12:00:00Z", [U("1206", 4780)])
    step(db, cfg, "2026-09-02T12:00:00Z", [U("1206", 4700)])
    out = export_site(cfg, str(tmp_path / "site"))
    d = json.loads((out / "data.json").read_text())
    assert d["units"][0]["price"] == 4700 and len(d["history"]["foundry:1206"]["prices"]) == 2
    html = (out / "index.html").read_text()
    assert "window.APTMON_STATIC = true" in html
    assert (out / "sw.js").exists() and (out / "static" / "icon-180.png").exists()


def test_concession_new_then_ended_after_a_day(env):
    cfg, db = env
    ch = db.sync_concessions("foundry", {"a": "6 weeks free"}, "2026-09-01T12:00:00Z")
    assert ch == [("concession", "6 weeks free")]
    assert db.sync_concessions("foundry", {"a": "6 weeks free"}, "2026-09-01T16:00:00Z") == []   # still up
    assert db.sync_concessions("foundry", {}, "2026-09-01T20:00:00Z") == []                    # flap: too soon
    assert db.sync_concessions("foundry", {}, "2026-09-02T20:00:00Z") == [("concession_end", "6 weeks free")]
    assert db.active_concessions() == []
    assert db.sync_concessions("foundry", {"a": "6 weeks free"}, "2026-09-05T12:00:00Z") == [("concession", "6 weeks free")]


def test_unsent_events_excludes_never_attempted(env):
    """notify_attempted=0 means we never tried (the kind wasn't configured to notify, or it
    predates this feature) - unsent_events must never resurface those, only genuine delivery
    failures (attempted=1, notified=0)."""
    from aptmon.models import utcnow
    cfg, db = env
    ts = utcnow()
    eid1 = db.add_event(ts, None, "foundry", None, "increase", 100, 110, "msg")
    eid2 = db.add_event(ts, None, "foundry", None, "off_market", None, None, "msg2")
    db.mark_attempted([eid2])
    assert db.unsent_events() == [eid2]


def test_run_retries_previously_failed_notification(env, monkeypatch):
    """A notification that was attempted last run but never delivered (ntfy.sh down, say) gets
    picked back up and retried on the next run, instead of vanishing forever."""
    from aptmon import concessions, monitor
    from aptmon.models import utcnow
    cfg, db = env
    eid = db.add_event(utcnow(), "foundry:1", "foundry", "1", "off_market", 4000, None,
                       "Off market (leased or pulled): The Foundry #1")
    db.mark_attempted([eid])
    monkeypatch.setattr(monitor, "scrape_building", lambda *a, **k: ([], "test", []))
    monkeypatch.setattr(concessions, "check_building", lambda db, f, key, b, ts: [])
    sent_events = []

    class FakeNotifier:
        def __init__(self, cfg):
            pass

        def send_events(self, events):
            sent_events.extend(events)
            return True

    monkeypatch.setattr(monitor, "Notifier", FakeNotifier)
    monitor.run(cfg, only=["foundry"], debug=False, notify=True)
    assert any(e["id"] == eid for e in sent_events)
    assert db.one("SELECT notified FROM events WHERE id=?", eid)["notified"] == 1


def test_concession_events_notify(env, monkeypatch):
    from aptmon import concessions, monitor
    cfg, db = env
    monkeypatch.setattr(concessions, "check_building",
                        lambda db, f, key, b, ts: [("concession", "1 month free on 2BRs")])
    ids = monitor.check_concessions(db, cfg, None, "foundry", cfg["buildings"]["foundry"], "2026-09-01T12:00:00Z")
    ev = db.one("SELECT * FROM events WHERE id=?", ids[0])
    assert ev["kind"] == "concession" and ev["message"] == "The Foundry special: 1 month free on 2BRs"
