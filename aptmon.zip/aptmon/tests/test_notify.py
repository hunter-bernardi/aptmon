from aptmon import notify
from aptmon.notify import Notifier


def _cfg(**ntfy):
    return {"dashboard_url": "", "notify": {"channels": {
        "console": {"enabled": False}, "macos": {"enabled": False},
        "ntfy": {"enabled": True, "topic": "t", "server": "https://ntfy.sh", **ntfy},
        "email": {"enabled": False}, "webhook": {"enabled": False},
    }}}


def test_send_retries_once_then_succeeds(monkeypatch):
    """A channel that raises once (a transient ntfy.sh hiccup) shouldn't lose the notification -
    it gets one immediate retry before giving up."""
    calls = []

    def flaky(c, title, body, url=None):
        calls.append(1)
        if len(calls) == 1:
            raise RuntimeError("connection reset")

    monkeypatch.setattr(Notifier, "_ntfy", staticmethod(flaky))
    monkeypatch.setattr(notify.time, "sleep", lambda s: None)   # don't actually wait in tests
    n = Notifier(_cfg())
    assert n.send("title", "body") is True
    assert len(calls) == 2


def test_send_gives_up_after_one_retry(monkeypatch):
    calls = []

    def always_fails(c, title, body, url=None):
        calls.append(1)
        raise RuntimeError("still down")

    monkeypatch.setattr(Notifier, "_ntfy", staticmethod(always_fails))
    monkeypatch.setattr(notify.time, "sleep", lambda s: None)
    n = Notifier(_cfg())
    assert n.send("title", "body") is False
    assert len(calls) == 2                                           # tried, retried, then gave up
