from pathlib import Path

from aptmon.fetch import Fetcher


class FakePage:
    """Stands in for a Playwright Page - just enough for dump_failure()."""
    def __init__(self, content="<html>Attention Required! | Cloudflare</html>", screenshot_ok=True):
        self._content = content
        self.screenshot_ok = screenshot_ok
        self.screenshot_calls = []

    def screenshot(self, path, timeout=None):
        self.screenshot_calls.append(path)
        if not self.screenshot_ok:
            raise RuntimeError("target closed")
        Path(path).write_bytes(b"\x89PNG\r\n\x1a\n")   # minimal PNG header is enough for this test

    def content(self):
        return self._content


def _fetcher(tmp_path, debug=True):
    cfg = {"debug_dir": str(tmp_path / "debug"), "request_timeout": 30}
    return Fetcher(cfg, debug=debug)


def test_dump_failure_writes_screenshot_and_html(tmp_path):
    f = _fetcher(tmp_path)
    page = FakePage()
    f.dump_failure("https://www.lincolncommonapartments.com/floorplans/sheffield", page,
                   TimeoutError("Page.goto: Timeout 60000ms exceeded."))
    files = list(Path(f.debug_dir).glob("*FAILED*"))
    assert any(p.suffix == ".png" for p in files)
    assert any(p.suffix == ".html" for p in files)
    txt = next(p for p in files if p.suffix == ".txt")
    assert "TimeoutError" in txt.read_text() and "60000ms" in txt.read_text()
    html = next(p for p in files if p.suffix == ".html")
    assert "Cloudflare" in html.read_text()


def test_dump_failure_is_noop_when_debug_off(tmp_path):
    f = _fetcher(tmp_path, debug=False)
    f.dump_failure("https://x", FakePage(), RuntimeError("boom"))
    assert not Path(f.debug_dir).exists()


def test_dump_failure_survives_a_dead_page(tmp_path):
    """If the browser context is already gone, screenshot()/content() can themselves raise -
    dump_failure must swallow that and still leave the .txt with the original error."""
    f = _fetcher(tmp_path)
    page = FakePage(screenshot_ok=False)
    page.content = lambda: (_ for _ in ()).throw(RuntimeError("context closed"))
    f.dump_failure("https://liveonechicago.com/floor-plans", page, TimeoutError("Page.goto: Timeout"))
    files = list(Path(f.debug_dir).glob("*FAILED*"))
    assert any(p.suffix == ".txt" for p in files)
    assert not any(p.suffix == ".png" for p in files)      # screenshot failed - no partial file left behind
