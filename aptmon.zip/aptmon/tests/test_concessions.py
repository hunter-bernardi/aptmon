from aptmon.concessions import apply_effective_rent, confirmed_override, effective_rent, extract, parse_offer


def test_parse_offer_weeks_free():
    assert parse_offer("Get 6 weeks free on select homes!") == {"kind": "weeks", "amount": 6.0}


def test_parse_offer_months_free_word_number():
    assert parse_offer("Look and lease today and get one month free.") == {"kind": "months", "amount": 1.0}


def test_parse_offer_first_month_free_idiom():
    assert parse_offer("First month free on 12+ month leases.") == {"kind": "months", "amount": 1.0}


def test_parse_offer_flat_dollar_bonus_is_not_convertible():
    # "up to $X" is an advertised ceiling, not a confirmed per-unit figure - see concessions.py's
    # module docstring for why this is deliberately never turned into a number. Checked, not assumed:
    # for Foundry specifically, sources disagree on both the amount and whether it's even live.
    assert parse_offer("Lease Today and Get Up to $3,000 in Move-In Bonuses!") is None


def test_parse_offer_no_number_returns_none():
    assert parse_offer("Reduced security deposit available - ask us how.") is None
    assert parse_offer("Look & lease special this week only.") is None


def test_effective_rent_weeks_free_scales_with_unit_price():
    # 6 weeks free on a $5,000/mo unit: weekly rent = 5000*12/52 = 1153.85, x6 = 6923.08,
    # spread over 12 months = 576.92 off -> ~4423
    eff = effective_rent(5000, ["Get 6 weeks free on select homes!"])
    assert eff == 4423


def test_effective_rent_flat_dollar_cap_never_produces_a_number():
    # This is the whole point: an "up to $X" concession must never silently become a rent figure.
    eff = effective_rent(5657, ["Lease Today and Get Up to $3,000 in Move-In Bonuses!"])
    assert eff is None


def test_effective_rent_picks_best_single_free_period_offer_not_summed():
    offers = ["1 month free on select units", "2 weeks free for a limited time"]
    eff = effective_rent(4000, offers)
    assert eff == 3667          # 1 month free ($4000) beats 2 weeks (~$1846)


def test_effective_rent_ignores_dollar_offer_even_alongside_a_real_one():
    # a flat-dollar offer sitting next to a real free-period offer still can't move the number -
    # only the free-period offer contributes
    offers = ["1 month free on select units", "Lease Today and Get Up to $3,000 in Move-In Bonuses!"]
    assert effective_rent(4000, offers) == 3667


def test_effective_rent_none_when_no_price_or_no_parseable_offer():
    assert effective_rent(None, ["1 month free"]) is None
    assert effective_rent(4000, []) is None
    assert effective_rent(4000, ["Reduced deposit, ask us how"]) is None
    assert effective_rent(4000, ["Lease Today and Get Up to $3,000 in Move-In Bonuses!"]) is None


def test_apply_effective_rent_only_touches_units_with_a_free_period_offer():
    units = [
        {"key": "a", "building": "foundry", "price": 5657},          # only a flat $-cap offer active
        {"key": "b", "building": "wolf_point_east", "price": 4000},   # no active concession
        {"key": "c", "building": "cascade", "price": 4200},           # a real free-period offer
    ]
    specials = {
        "foundry": [{"text": "Lease Today and Get Up to $3,000 in Move-In Bonuses!", "since": "x"}],
        "cascade": [{"text": "1 month free on select 2BRs", "since": "x"}],
    }
    apply_effective_rent(units, specials, lease_term_months=12)
    assert "eff_price" not in units[0]      # dollar-cap offer -> never guessed
    assert "eff_price" not in units[1]      # no offer at all
    assert units[2]["eff_price"] == 3850    # 1 month free on $4200 -> 4200 - 4200/12 = 3850


def test_confirmed_override_applies_to_matching_beds_only():
    bcfg = {"concession_overrides": [{"beds": [2.0], "amount": 3000, "note": "phone-confirmed"}]}
    assert confirmed_override(bcfg, 2.0) == 3000
    assert confirmed_override(bcfg, 1.0) is None
    assert confirmed_override({}, 2.0) is None


def test_confirmed_override_with_no_beds_key_applies_to_everything():
    bcfg = {"concession_overrides": [{"amount": 500, "note": "applies building-wide"}]}
    assert confirmed_override(bcfg, 1.0) == 500
    assert confirmed_override(bcfg, 2.0) == 500


def test_apply_effective_rent_uses_confirmed_override_for_a_flat_dollar_concession():
    # Foundry's "up to $3,000" was verified by phone to be a flat $3,000 for 2BRs - now that it's
    # a confirmed fact (not scraped ad copy), it's used: 5657 - 3000/12 = 5407
    units = [{"key": "a", "building": "foundry", "price": 5657, "beds": 2.0}]
    specials = {"foundry": [{"text": "Lease Today and Get Up to $3,000 in Move-In Bonuses!", "since": "x"}]}
    buildings_cfg = {"foundry": {"concession_overrides": [{"beds": [2.0], "amount": 3000}]}}
    apply_effective_rent(units, specials, buildings_cfg, lease_term_months=12)
    assert units[0]["eff_price"] == 5407


def test_confirmed_override_never_applies_once_the_special_is_no_longer_posted():
    # the override has no expiry of its own - it rides on the building actually having an active
    # concession right now, so it turns off the moment a concession_end is detected
    units = [{"key": "a", "building": "foundry", "price": 5657, "beds": 2.0}]
    buildings_cfg = {"foundry": {"concession_overrides": [{"beds": [2.0], "amount": 3000}]}}
    apply_effective_rent(units, specials_by_building={}, buildings_cfg=buildings_cfg, lease_term_months=12)
    assert "eff_price" not in units[0]


def test_confirmed_override_does_not_apply_to_a_non_matching_bed_count():
    units = [{"key": "a", "building": "foundry", "price": 3200, "beds": 1.0}]   # a 1BR, override is 2BR-only
    specials = {"foundry": [{"text": "Lease Today and Get Up to $3,000 in Move-In Bonuses!", "since": "x"}]}
    buildings_cfg = {"foundry": {"concession_overrides": [{"beds": [2.0], "amount": 3000}]}}
    apply_effective_rent(units, specials, buildings_cfg, lease_term_months=12)
    assert "eff_price" not in units[0]


def test_extract_still_works_unchanged():
    html = "<html><body><p>Lease Today and Get Up to $3,000 in Move-In Bonuses!</p></body></html>"
    assert extract(html) == ["Lease Today and Get Up to $3,000 in Move-In Bonuses!"]
