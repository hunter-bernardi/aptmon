# aptmon: 2BR price monitor

Tracks every advertised 2-bedroom at **Wolf Point East, The Foundry, Lincoln Common and The Row**.
Every morning at **7:00 AM Chicago time** it records each unit's asking rent, pushes a notification to
your iPhone for any price drop, and refreshes a dashboard you open from your Home Screen. The dashboard
has sortable unit cards, trend flags and a price history for each unit.

```
GitHub Actions (7 AM CT daily)  ──scrape──▶  4 building sites
        │ saves price history to data/aptmon.db (in the repo)
        ├──▶ ntfy push ──▶ iPhone notification ("Price drop: Wolf Point East #4207 …")
        └──▶ GitHub Pages ──▶ iPhone Home Screen web app (tap the alert to open it)
```

Your phone doesn't run the scraper. iOS won't let an app wake up on a schedule and drive a headless
browser, so a free GitHub runner does the scraping and your iPhone gets the alerts and the dashboard.
Nothing needs to stay switched on at your place.

## iPhone setup (about 10 minutes, one time)

**Fastest: on your Mac, unzip, then in Terminal run `cd aptmon && bash setup_github.sh`.** It does steps 1–4 for you (installs the GitHub CLI if needed, asks you to sign in once) and prints your alert topic and dashboard URL. The manual steps below are for reference.

**1. Put the code on GitHub**
- Create a new repository on github.com, for example `aptmon`, and upload this folder's contents
  (including the `.github` folder). If you use git:
  `git init && git add . && git commit -m init && git branch -M main && git remote add origin <url> && git push -u origin main`

**2. Turn on the web app hosting**
- Repo → **Settings → Pages → Build and deployment → Source: GitHub Actions**.
- Repo → **Settings → Actions → General → Workflow permissions: Read and write**.

**3. Set up alerts on your iPhone**
- Install **ntfy** from the App Store (free, no account needed).
- Tap **+** and subscribe to a topic name that's hard to guess, e.g. `hunter-2br-7Kq93xZ`.
  (Anyone who knows the name can read the topic.)
- On GitHub: repo → **Settings → Secrets and variables → Actions → New repository secret**:
  name `NTFY_TOPIC`, value = the same topic name.

**4. Run it once**
- Repo → **Actions → "2BR price check" → Run workflow**. The GitHub iPhone app has the same button.
- When it finishes (about 3 minutes), open `https://<your-github-username>.github.io/aptmon/` in Safari.
  Tap **Share → Add to Home Screen**. It opens full-screen like an app.

From then on it runs by itself every morning. When a price drops you get a push notification, and
tapping it opens the dashboard. The **Run now** button in the app goes to the GitHub page for an
on-demand check.

**Good to know**
- **Timing.** GitHub cron only runs in UTC and ignores daylight saving. The workflow is scheduled for
  both 12:00 and 13:00 UTC, and `aptmon due` lets exactly one of them scrape after 7:00 AM Central.
  GitHub can start scheduled jobs 5–20 minutes late at busy times.
  To change the time, edit `APTMON_RUN_AT_HOUR` and the two cron lines in `.github/workflows/monitor.yml`.
- **Privacy.** On a free GitHub account, Pages sites are public, even from a private repo. Anyone with
  the URL could see the listing prices you track. Nothing personal is published, and the ntfy topic stays
  in Secrets.
- **Silence means no drops.** You only get a notification when something changes. If a building's page
  stops parsing, you get one "scraper broken" alert, and the failed run's raw pages are attached to it
  under Actions → run → Artifacts.

## Running it on a Mac instead (optional)

```bash
cd aptmon
python3 -m venv .venv && source .venv/bin/activate
pip install -e .
playwright install chromium

aptmon doctor                 # dry run: what each scraper sees
aptmon run                    # one snapshot now
aptmon schedule               # daily at 7:00 via launchd (runs on wake if the Mac was asleep)
aptmon dashboard --open       # http://127.0.0.1:8050
```

To see the dashboard with sample history: `aptmon demo`, then `aptmon dashboard --db ~/.aptmon/demo.db`.
The demo numbers are **synthetic**.

## Where each building's data comes from

| Building | Source | How |
|---|---|---|
| Wolf Point East | SightMap embed `y8pxdmnjw19` (fallback: Entrata floor-plan grid) | headless browser, reads the map's unit JSON |
| The Foundry | SightMap embed `8xvrozk5vjk` (fallback: RealPage / site JSON) | same |
| Lincoln Common | RentCafe site `/floorplans` → each 2BR plan page | plain HTTP, one row per unit via its apply link |
| The Row | relatedrentals.com search + building page → unit detail page | browser for search, HTTP for `Apartment #NNNN` |

Each extractor runs in layers: first the site-specific parser, then a schema-agnostic JSON sniffer
that finds unit-like records (unit #, price, sq ft, beds) in whatever the page loads. This makes it
more tolerant of site redesigns than CSS selectors alone.

**The Wolf Point East fallback works at plan level.** If the SightMap source fails, WPE is tracked
per floor plan ("PLAN B4" etc.) at its "Base Rent From" price, not per unit, until SightMap works again.

## Alerts

- **Price drop**: `Price drop: Wolf Point East #4207 $5,657 -> $5,495 (-$162, -2.9%) · B12`
- **Scraper broken**: sent once when a building's page stops parsing, and once when it recovers.
  A failed scrape never marks units as leased, so an outage doesn't produce false "off market"
  events or break the price history.
- Optional: new listing and price increase alerts (`notify.on_new_unit`, `notify.on_increase`).

Channels: **ntfy** push to your iPhone (set by the `NTFY_TOPIC` secret in the cloud setup), macOS
banner (Mac setup), email via SMTP, and Slack/Discord webhook. Run `aptmon test-notify` to check them.

## How trends are measured

- **Unit trend**: a least-squares slope of the unit's daily price (last price each day, carried
  forward) over the last 30 days, in $/week. Down, Up, or Flat (within ±$10/wk).
- **Off peak**: current ask versus the highest ask seen for that unit.
- **Same-unit index (building chart)**: the average % change of each live unit versus *its own*
  first ask. This is a repeat-sales style index. Median ask moves whenever a penthouse lists or a
  cheap unit leases; the same-unit index doesn't, so it's the better read on whether a building is
  cutting. Median ask and median $/sf are available as toggles.

## Dashboard

On iPhone, units are shown as cards. Use the sort menu and the ↑/↓ button to order them, and tap a card
to see its price history. On a wider screen, click any column header to sort. Filter by building chip, search, "trending down only", or "show
off-market". Click a row to see its price history and event log. Scrape now runs a pass in the
background (Mac setup), and CSV downloads the full table.

## When a site changes

1. `aptmon doctor --only the_row` shows what was parsed. Raw HTML and JSON are saved to `~/.aptmon/debug/`.
2. If a URL moved (a new SightMap embed id, for example), override it in `config.yaml` under `buildings:`.
3. Parsers are in `aptmon/scrapers/`. Tests with fixtures are in `tests/` (`pytest`).

## Files

```
aptmon/
  scrapers/   sightmap.py, rentcafe.py, related.py, generic.py (JSON sniffer), __init__.py (fallback chain)
  monitor.py  diff vs. history -> events (drop / increase / new / off_market / relisted / broken)
  analytics.py trend slope, off-peak, same-unit index
  notify.py   console / macOS / ntfy / email / webhook
  dashboard/  Flask + one self-contained HTML page (no CDN)
  db.py       SQLite: units, prices (one row per unit per run), events, runs, scrape_status
```

Data is stored in `data/aptmon.db` in the cloud setup (committed after each run) and in `~/.aptmon/aptmon.db` on a Mac.

Scraping is read-only and runs once a day, which is light enough on the leasing sites.
